'use client';

import {
  useEffect,
  useRef,
  type ReactNode,
  type KeyboardEvent,
} from 'react';
import { Icon, type IconName } from './Icon';
import styles from './Menu.module.css';

// ─── MenuItem ────────────────────────────────────────────────────────────────
// DLS node 120:3899
// States: default | hover (CSS) | active (selected — blush bg, brand text, check)
// Destructive item: red text, trash icon — appears in action-menu type only

export interface MenuItemProps {
  label: string;
  /** DS icon name — leading icon, 16px */
  icon?: IconName;
  /** Selected/active state — blush bg (#f5eaec), brand text, check icon right */
  active?: boolean;
  /** Destructive — red text, used for danger actions (Delete) */
  destructive?: boolean;
  /** Divider line rendered above this item */
  dividerAbove?: boolean;
  onClick?: () => void;
  disabled?: boolean;
}

export function MenuItem({
  label,
  icon,
  active = false,
  destructive = false,
  dividerAbove = false,
  onClick,
  disabled = false,
}: MenuItemProps) {
  const itemClass = [
    styles.item,
    active ? styles.itemActive : '',
    destructive ? styles.itemDestructive : '',
    disabled ? styles.itemDisabled : '',
  ].filter(Boolean).join(' ');

  const iconColor = destructive ? '#8b2020' : active ? '#6b1e2e' : '#6b5e55';

  return (
    <>
      {dividerAbove && <div className={styles.divider} role="separator" />}
      <li
        role="menuitem"
        aria-selected={active}
        aria-disabled={disabled}
        tabIndex={disabled ? -1 : 0}
        className={itemClass}
        onClick={() => !disabled && onClick?.()}
        onKeyDown={(e: KeyboardEvent) => {
          if ((e.key === 'Enter' || e.key === ' ') && !disabled) {
            e.preventDefault();
            onClick?.();
          }
        }}
      >
        {icon && (
          <span className={styles.itemIcon} aria-hidden="true">
            <Icon name={icon} size={16} color={iconColor} />
          </span>
        )}
        <span className={styles.itemLabel}>{label}</span>
        {active && (
          <span className={styles.itemCheck} aria-hidden="true">
            <Icon name="check" size={16} color="#6b1e2e" />
          </span>
        )}
      </li>
    </>
  );
}

// ─── Menu ─────────────────────────────────────────────────────────────────────
// DLS node 112:163
// Types:
//   dropdown     — plain option list (no selection concept)
//   context-menu — supports active/selected item with check
//   action-menu  — context-menu + destructive section (pass destructive MenuItem
//                  with dividerAbove={true} as the last child)

export type MenuType = 'dropdown' | 'context-menu' | 'action-menu';

export interface MenuProps {
  open: boolean;
  onClose: () => void;
  children: ReactNode;
  type?: MenuType;
  /** Ref of the triggering element — excluded from outside-click detection */
  anchorRef?: React.RefObject<HTMLElement>;
  /** Menu alignment relative to its nearest positioned ancestor */
  align?: 'left' | 'right';
  'aria-label'?: string;
  className?: string;
}

export function Menu({
  open,
  onClose,
  children,
  type = 'dropdown',
  anchorRef,
  align = 'right',
  'aria-label': ariaLabel = 'Menu',
  className,
}: MenuProps) {
  const menuRef = useRef<HTMLUListElement>(null);

  // Close on outside click
  useEffect(() => {
    if (!open) return;
    const handler = (e: MouseEvent) => {
      if (menuRef.current?.contains(e.target as Node)) return;
      if (anchorRef?.current?.contains(e.target as Node)) return;
      onClose();
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, [open, onClose, anchorRef]);

  // Escape + arrow key navigation
  useEffect(() => {
    if (!open) return;
    const handler = (e: globalThis.KeyboardEvent) => {
      if (e.key === 'Escape') { onClose(); return; }
      if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
        e.preventDefault();
        const items = Array.from(
          menuRef.current?.querySelectorAll<HTMLElement>(
            '[role="menuitem"]:not([aria-disabled="true"])'
          ) ?? []
        );
        const idx = items.indexOf(document.activeElement as HTMLElement);
        const next = e.key === 'ArrowDown'
          ? items[Math.min(idx + 1, items.length - 1)]
          : items[Math.max(idx - 1, 0)];
        next?.focus();
      }
    };
    document.addEventListener('keydown', handler);
    return () => document.removeEventListener('keydown', handler);
  }, [open, onClose]);

  // Auto-focus first item on open
  useEffect(() => {
    if (!open) return;
    const t = setTimeout(() => {
      const first = menuRef.current?.querySelector<HTMLElement>(
        '[role="menuitem"]:not([aria-disabled="true"])'
      );
      first?.focus();
    }, 10);
    return () => clearTimeout(t);
  }, [open]);

  if (!open) return null;

  return (
    <ul
      ref={menuRef}
      role="menu"
      aria-label={ariaLabel}
      className={[
        styles.menu,
        align === 'right' ? styles.alignRight : styles.alignLeft,
        type === 'action-menu' ? styles.overflow : '',
        className ?? '',
      ].filter(Boolean).join(' ')}
    >
      {children}
    </ul>
  );
}
