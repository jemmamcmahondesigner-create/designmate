/**
 * Button — DesignMate DS
 *
 * Canonical implementation extracted from DLS (Figma node 2:673).
 * Do not reimplement — import from '@/components/ui/ds'.
 *
 * Variants:  primary | secondary | ghost | destructive | accent | primary-on-dark | ghost-on-dark
 * Sizes:     sm | md | lg
 * States:    default | disabled
 * Icon:      none | leading | trailing
 */

import React from 'react'
import { Icon } from './Icon'
import type { IconName } from './Icon'
import styles from './Button.module.css'

// ─── Props ────────────────────────────────────────────────────────────────────

export interface ButtonProps {
  /** The button label text */
  label: string
  /** Visual variant — controls colour scheme */
  variant?: 'primary' | 'secondary' | 'ghost' | 'destructive' | 'accent' | 'primary-on-dark' | 'ghost-on-dark'
  /** Size — controls height, padding, and font size */
  size?: 'sm' | 'md' | 'lg'
  /** Whether the button is disabled */
  disabled?: boolean
  /** Icon placement relative to label */
  icon?: 'none' | 'leading' | 'trailing'
  /** Icon-only mode — hides label, requires aria-label on parent or label used as aria-label */
  iconOnly?: boolean
  /** Icon name from the DLS icon registry */
  iconName?: IconName
  /** Click handler */
  onClick?: (e: React.MouseEvent<HTMLButtonElement>) => void
  /** Additional class names — use sparingly, only for layout positioning */
  className?: string
  /** HTML button type */
  type?: 'button' | 'submit' | 'reset'
  /** Accessible label — required when iconOnly is true */
  'aria-label'?: string
}

// ─── Component ────────────────────────────────────────────────────────────────

export function Button({
  label,
  variant = 'secondary',
  size = 'md',
  disabled = false,
  icon = 'none',
  iconOnly = false,
  iconName,
  onClick,
  className,
  type = 'button',
  'aria-label': ariaLabel,
}: ButtonProps) {
  const iconSize = (size === 'lg' ? 16 : 14) as 14 | 16

  const classList = [
    styles.root,
    styles[`variant-${variant}`],
    styles[`size-${size}`],
    iconOnly ? styles.iconOnly : '',
    className ?? '',
  ]
    .filter(Boolean)
    .join(' ')

  return (
    <button
      type={type}
      className={classList}
      disabled={disabled}
      aria-disabled={disabled}
      aria-label={iconOnly ? (ariaLabel ?? label) : ariaLabel}
      onClick={disabled ? undefined : onClick}
    >
      {icon === 'leading' && iconName && (
        <Icon name={iconName} size={iconSize} />
      )}

      {!iconOnly && (
        <span className={styles.label}>{label}</span>
      )}

      {icon === 'trailing' && iconName && (
        <Icon name={iconName} size={iconSize} />
      )}
    </button>
  )
}

export default Button
