/**
 * Icon — DesignMate DS
 *
 * Canonical implementation of the DLS icon system.
 * Do not import icons from anywhere else — import from '@/components/ui/ds'.
 *
 * All icons are inline SVG — no image files, no external CDN, no expiry.
 * Paths are traced from the Figma DLS vector nodes.
 *
 * currentColor is used throughout — icon inherits colour from its parent.
 * Sizes: 14 | 16 | 20 | 24 (px). Default: 16.
 */

import React from 'react'

// ─── Icon name registry ───────────────────────────────────────────────────────

export type IconName =
  // Action
  | 'plus'
  | 'close'
  | 'upload'
  | 'stretch'
  | 'kebab'
  | 'search'
  | 'check'
  // Content / navigation
  | 'chevron-down'
  | 'chevron-right'
  | 'chevron-left'
  | 'link'
  // Nav
  | 'nav-mark'
  | 'nav-archive'
  | 'nav-reviews'

// ─── Props ────────────────────────────────────────────────────────────────────

export interface IconProps {
  /** Icon name from the DLS registry */
  name: IconName
  /** Size in px — matches DLS usage: 14 (in buttons), 16 (controls), 20 (nav), 24 (standalone) */
  size?: 14 | 16 | 20 | 24
  /** aria-label — provide when icon is the sole communicator (no adjacent label) */
  'aria-label'?: string
  /** Additional className — for colour overrides via CSS custom properties */
  className?: string
}

// ─── SVG path definitions ─────────────────────────────────────────────────────
// All paths traced from Figma DLS vector nodes.
// viewBox is always "0 0 24 24" — scaled via width/height props.

const paths: Record<IconName, React.ReactElement> = {
  // ── Action/plus ────────────────────────────────────────────────────────────
  // Figma: Icons/Action/plus — Create / add
  'plus': (
    <path
      d="M12 4v16M4 12h16"
      stroke="currentColor"
      strokeWidth="1.75"
      strokeLinecap="round"
    />
  ),

  // ── Action/close ──────────────────────────────────────────────────────────
  // Figma: Icons/Action/close — Close / dismiss / remove
  'close': (
    <path
      d="M18 6L6 18M6 6l12 12"
      stroke="currentColor"
      strokeWidth="1.75"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
  ),

  // ── Action/upload ─────────────────────────────────────────────────────────
  // Figma: Icons/Action/upload — Upload file
  'upload': (
    <>
      <path
        d="M12 15V4M12 4l-3.5 3.5M12 4l3.5 3.5"
        stroke="currentColor"
        strokeWidth="1.75"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M4 15v3a2 2 0 002 2h12a2 2 0 002-2v-3"
        stroke="currentColor"
        strokeWidth="1.75"
        strokeLinecap="round"
      />
    </>
  ),

  // ── Action/stretch ────────────────────────────────────────────────────────
  // Figma: Icons/Action/stretch — Textarea resize handle (bottom-right corner)
  'stretch': (
    <>
      <path d="M20 14l-6 6" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
      <path d="M20 19l-1 1" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
    </>
  ),

  // ── Action/kebab ──────────────────────────────────────────────────────────
  // Figma: Icons/Action/kebab — Overflow / more options (3 vertical dots)
  'kebab': (
    <>
      <circle cx="12" cy="5" r="1.25" fill="currentColor" />
      <circle cx="12" cy="12" r="1.25" fill="currentColor" />
      <circle cx="12" cy="19" r="1.25" fill="currentColor" />
    </>
  ),

  // ── Action/search ─────────────────────────────────────────────────────────
  // Figma: Icons/Content/search — Search field icon
  'search': (
    <>
      <circle
        cx="10.5"
        cy="10.5"
        r="6"
        stroke="currentColor"
        strokeWidth="1.75"
      />
      <path
        d="M15 15l4.5 4.5"
        stroke="currentColor"
        strokeWidth="1.75"
        strokeLinecap="round"
      />
    </>
  ),

  // ── Action/check ─────────────────────────────────────────────────────────
  // Figma: check-fill-sm — Checkbox tick
  'check': (
    <path
      d="M5 12l4.5 4.5L19 7"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
  ),

  // ── Content/chevron-down ─────────────────────────────────────────────────
  // Figma: Icons/Content/chevron-down — Expand / dropdown
  'chevron-down': (
    <path
      d="M6 9l6 6 6-6"
      stroke="currentColor"
      strokeWidth="1.75"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
  ),

  // ── Content/chevron-right ─────────────────────────────────────────────────
  // Figma: Icons/Content/chevron-right — Navigate right / next
  'chevron-right': (
    <path
      d="M9 6l6 6-6 6"
      stroke="currentColor"
      strokeWidth="1.75"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
  ),

  // ── Content/chevron-left ──────────────────────────────────────────────────
  // Figma: Icons/Content/chevron-left — Navigate left / back
  'chevron-left': (
    <path
      d="M15 6l-6 6 6 6"
      stroke="currentColor"
      strokeWidth="1.75"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
  ),

  // ── Content/link ─────────────────────────────────────────────────────────
  // Figma: Icons/Content/link — Linked reference / source file
  'link': (
    <>
      <path
        d="M10 13a5 5 0 007.54.54l3-3a5 5 0 00-7.07-7.07l-1.72 1.71"
        stroke="currentColor"
        strokeWidth="1.75"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M14 11a5 5 0 00-7.54-.54l-3 3a5 5 0 007.07 7.07l1.71-1.71"
        stroke="currentColor"
        strokeWidth="1.75"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </>
  ),

  // ── Nav/mark ─────────────────────────────────────────────────────────────
  // Figma: Icons/Nav/mark — Dashboard / home (DesignMate logomark)
  'nav-mark': (
    <>
      <rect x="4" y="4" width="7" height="7" rx="1.5" fill="currentColor" />
      <rect x="13" y="4" width="7" height="7" rx="1.5" fill="currentColor" />
      <rect x="4" y="13" width="7" height="7" rx="1.5" fill="currentColor" />
      <rect x="13" y="13" width="7" height="7" rx="1.5" fill="currentColor" />
    </>
  ),

  // ── Nav/archive ───────────────────────────────────────────────────────────
  // Figma: Icons/Nav/archive — Archived reviews
  'nav-archive': (
    <>
      <path
        d="M4 7h16v2H4V7zM6 9h12l-1 10H7L6 9z"
        stroke="currentColor"
        strokeWidth="1.5"
        strokeLinejoin="round"
        fill="none"
      />
      <path
        d="M9.5 13h5"
        stroke="currentColor"
        strokeWidth="1.5"
        strokeLinecap="round"
      />
    </>
  ),

  // ── Nav/reviews ───────────────────────────────────────────────────────────
  // Figma: Icons/Nav/reviews — Review list
  'nav-reviews': (
    <>
      <rect
        x="4"
        y="4"
        width="16"
        height="16"
        rx="2"
        stroke="currentColor"
        strokeWidth="1.5"
        fill="none"
      />
      <path
        d="M8 9h8M8 12h8M8 15h5"
        stroke="currentColor"
        strokeWidth="1.5"
        strokeLinecap="round"
      />
    </>
  ),
}

// ─── Component ────────────────────────────────────────────────────────────────

export function Icon({
  name,
  size = 16,
  'aria-label': ariaLabel,
  className,
}: IconProps) {
  const isDecorative = !ariaLabel

  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      aria-hidden={isDecorative}
      aria-label={ariaLabel}
      role={ariaLabel ? 'img' : undefined}
      focusable="false"
      className={className}
      style={{ flexShrink: 0, display: 'inline-block' }}
    >
      {paths[name]}
    </svg>
  )
}

export default Icon
