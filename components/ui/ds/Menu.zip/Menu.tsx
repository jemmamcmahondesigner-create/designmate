/**
 * Menu + MenuItem - DesignMate DS
 *
 * Canonical implementation extracted from DLS (Figma node 35:10375).
 * Do not reimplement - import from '@/components/ui/ds'.
 *
 * Menu: the surface shell - white card with shadow, 240px wide, 4px y-padding.
 * MenuItem: individual action row - icon + label, hover state, destructive variant.
 *
 * IMPORTANT: This component renders the visual shell and items only.
 * Positioning and open/close behaviour is handled by Radix at the call site.
 * Wrap Menu in a Radix DropdownMenuContent or PopoverContent.
 *
 * Types from DLS:
 *   dropdown    - options for a Select (list of choices)
 *   context     - right-click or kebab menu (edit/delete actions)
 *   action-menu - split button menu (New Review, New Project etc.)
 */

import React from 'react'
import { Icon } from './Icon'
import type { IconName } from './Icon'
import styles from './Menu.module.css'

// ─── MenuItem ────────────────────────────────────────────────────────────────

export interface MenuItemProps {
  /** Item label */
  label: string
  /** Optional DS icon shown to the left of the label */
  iconName?: IconName
  /** Destructive variant - red text, red hover */
  destructive?: boolean
  /** Disabled state */
  disabled?: boolean
  /** Click handler */
  onClick?: () => void
  /** Additional className */
  className?: string
}

export function MenuItem({
  label,
  iconName,
  destructive = false,
  disabled = false,
  onClick,
  className,
}: MenuItemProps) {
  const classList = [
    styles.item,
    destructive ? styles.itemDestructive : '',
    disabled ? styles.itemDisabled : '',
    className ?? '',
  ].filter(Boolean).join(' ')

  return (
    <button
      type="button"
      className={classList}
      onClick={disabled ? undefined : onClick}
      disabled={disabled}
      aria-disabled={disabled}
      role="menuitem"
    >
      {iconName && (
        <span className={styles.itemIcon}>
          <Icon name={iconName} size={16} />
        </span>
      )}
      <span className={styles.itemLabel}>{label}</span>
    </button>
  )
}

// ─── MenuSeparator ───────────────────────────────────────────────────────────

export function MenuSeparator() {
  return <div className={styles.separator} role="separator" aria-hidden="true" />
}

// ─── Menu ────────────────────────────────────────────────────────────────────

export interface MenuProps {
  /** Menu items and separators */
  children: React.ReactNode
  /** Additional className for positioning overrides */
  className?: string
  /** aria-label for screen readers */
  'aria-label'?: string
}

export function Menu({
  children,
  className,
  'aria-label': ariaLabel,
}: MenuProps) {
  return (
    <div
      className={`${styles.menu} ${className ?? ''}`}
      role="menu"
      aria-label={ariaLabel}
    >
      {children}
    </div>
  )
}

export default Menu
