// Add these two lines to components/ui/ds/index.ts

export { Tag } from './Tag';
export type { TagProps, TagVariant, TagSize, TagIcon } from './Tag';
