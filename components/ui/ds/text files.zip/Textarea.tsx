'use client';

import { useId } from 'react';
import styles from './Textarea.module.css';

export type TextareaSize = 'sm' | 'md' | 'lg';
export type TextareaState = 'default' | 'error' | 'disabled' | 'read-only';

export interface TextareaProps {
  label?: string;
  showLabel?: boolean;
  placeholder?: string;
  helperText?: string;
  showHelper?: boolean;
  errorText?: string;
  value?: string;
  defaultValue?: string;
  size?: TextareaSize;
  state?: TextareaState;
  rows?: number;
  onChange?: (e: React.ChangeEvent<HTMLTextAreaElement>) => void;
  id?: string;
  name?: string;
  className?: string;
}

export function Textarea({
  label = 'Label',
  showLabel = true,
  placeholder = 'Placeholder text for multiline content...',
  helperText,
  showHelper = false,
  errorText,
  value,
  defaultValue,
  size = 'sm',
  state = 'default',
  rows,
  onChange,
  id: idProp,
  name,
  className,
}: TextareaProps) {
  const autoId = useId();
  const id = idProp ?? autoId;

  const isDisabled = state === 'disabled';
  const isReadOnly = state === 'read-only';
  const isError = state === 'error';

  const wrapClass = [styles.wrap, className ?? ''].filter(Boolean).join(' ');

  const fieldClass = [
    styles.field,
    styles[`size-${size}`],
    isError ? styles.fieldError : '',
    isDisabled ? styles.fieldDisabled : '',
    isReadOnly ? styles.fieldReadOnly : '',
  ]
    .filter(Boolean)
    .join(' ');

  const labelClass = [
    styles.label,
    isDisabled ? styles.labelDisabled : '',
    isError ? styles.labelError : '',
  ]
    .filter(Boolean)
    .join(' ');

  const helperClass = [
    styles.helper,
    isDisabled ? styles.helperDisabled : '',
    isError ? styles.helperError : '',
  ]
    .filter(Boolean)
    .join(' ');

  return (
    <div className={wrapClass}>
      {showLabel && label && (
        <label htmlFor={id} className={labelClass}>
          {label}
        </label>
      )}

      <textarea
        id={id}
        name={name}
        className={fieldClass}
        placeholder={placeholder}
        disabled={isDisabled}
        readOnly={isReadOnly}
        rows={rows}
        value={value}
        defaultValue={defaultValue}
        onChange={onChange}
        aria-invalid={isError || undefined}
        aria-describedby={
          (showHelper && helperText) || (isError && errorText)
            ? `${id}-helper`
            : undefined
        }
      />

      {isError && errorText && (
        <p id={`${id}-helper`} className={helperClass} role="alert">
          {errorText}
        </p>
      )}

      {!isError && showHelper && helperText && (
        <p id={`${id}-helper`} className={helperClass}>
          {helperText}
        </p>
      )}
    </div>
  );
}
