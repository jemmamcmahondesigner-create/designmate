'use client';

import { useId } from 'react';
import styles from './Tooltip.module.css';

export type TooltipPosition = 'top' | 'bottom' | 'left' | 'right';

export interface TooltipProps {
  /** The tooltip label (primary line) */
  label: string;
  /** Optional supporting text — shown below label when provided */
  supportingText?: string;
  /** Tooltip position relative to the trigger */
  position?: TooltipPosition;
  /** The element that triggers the tooltip */
  children: React.ReactNode;
  className?: string;
}

export function Tooltip({
  label,
  supportingText,
  position = 'top',
  children,
  className,
}: TooltipProps) {
  const tooltipId = useId();

  const wrapClass = [styles.wrap, className ?? ''].filter(Boolean).join(' ');

  const bubbleClass = [
    styles.bubble,
    styles[`pos-${position}`],
  ]
    .filter(Boolean)
    .join(' ');

  return (
    <span className={wrapClass}>
      {/* Trigger — wraps whatever the consumer passes */}
      <span
        className={styles.trigger}
        aria-describedby={tooltipId}
        tabIndex={0}
      >
        {children}
      </span>

      {/* Tooltip bubble */}
      <span
        id={tooltipId}
        role="tooltip"
        className={bubbleClass}
      >
        <span className={styles.label}>{label}</span>
        {supportingText && (
          <span className={styles.supportingText}>{supportingText}</span>
        )}
      </span>
    </span>
  );
}
