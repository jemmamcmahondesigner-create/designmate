'use client';

import { Icon } from './index';
import styles from './ButtonGroup.module.css';

export type ButtonGroupVariant = 'primary' | 'secondary' | 'ghost';
export type ButtonGroupSize = 'sm' | 'md' | 'lg';

export interface ButtonGroupProps {
  /** Primary action label */
  label: string;
  variant?: ButtonGroupVariant;
  size?: ButtonGroupSize;
  /** Called when the primary label section is clicked */
  onPrimaryClick?: () => void;
  /** Called when the chevron/arrow trigger is clicked — opens a menu */
  onMenuClick?: () => void;
  /** aria-label for the arrow trigger */
  menuAriaLabel?: string;
  disabled?: boolean;
  className?: string;
}

export function ButtonGroup({
  label,
  variant = 'primary',
  size = 'sm',
  onPrimaryClick,
  onMenuClick,
  menuAriaLabel = 'More options',
  disabled = false,
  className,
}: ButtonGroupProps) {
  const rootClass = [
    styles.root,
    styles[`variant-${variant}`],
    styles[`size-${size}`],
    disabled ? styles.disabled : '',
    className ?? '',
  ]
    .filter(Boolean)
    .join(' ');

  const iconSize = size === 'sm' ? 14 : size === 'md' ? 16 : 20;

  return (
    <div className={rootClass} role="group">
      <button
        type="button"
        className={styles.primaryAction}
        onClick={onPrimaryClick}
        disabled={disabled}
      >
        {label}
      </button>

      <span className={styles.divider} aria-hidden="true" />

      <button
        type="button"
        className={styles.arrowTrigger}
        onClick={onMenuClick}
        disabled={disabled}
        aria-label={menuAriaLabel}
        aria-haspopup="menu"
      >
        <Icon name="chevron-down" size={iconSize} />
      </button>
    </div>
  );
}
