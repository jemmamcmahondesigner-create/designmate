'use client';

import { Avatar } from './Avatar';
import { StatusPill } from './StatusPill';
import styles from './ReviewCard.module.css';

export type ReviewStatus = 'draft' | 'in-review' | 'approved' | 'needs-changes' | 'blocked';

export interface ReviewCardProps {
  title: string;
  status: ReviewStatus;
  ownerName?: string;
  ownerAvatarSrc?: string;
  dateLabel?: string;
  description?: string;
  showDescription?: boolean;
  hasArtifact?: boolean;
  artifactLabel?: string;
  /** Iteration label shown right-aligned in the footer e.g. "Iteration 1" */
  iterationLabel?: string;
  commentCount?: number;
  decisionCount?: number;
  onClick?: () => void;
  className?: string;
}

const STATUS_LABELS: Record<ReviewStatus, string> = {
  draft: 'Draft',
  'in-review': 'In Review',
  approved: 'Approved',
  'needs-changes': 'Needs Changes',
  blocked: 'Blocked',
};

export function ReviewCard({
  title,
  status,
  ownerName,
  ownerAvatarSrc,
  dateLabel,
  description,
  showDescription = true,
  hasArtifact = false,
  artifactLabel,
  iterationLabel,
  commentCount,
  decisionCount,
  onClick,
  className,
}: ReviewCardProps) {
  const isNeedsChanges = status === 'needs-changes';
  const showFooter = commentCount !== undefined || decisionCount !== undefined || iterationLabel;

  const rootClass = [
    styles.root,
    styles[`status-${status}`],
    onClick ? styles.clickable : '',
    className ?? '',
  ].filter(Boolean).join(' ');

  return (
    <article
      className={rootClass}
      onClick={onClick}
      role={onClick ? 'button' : undefined}
      tabIndex={onClick ? 0 : undefined}
      onKeyDown={onClick ? (e) => e.key === 'Enter' && onClick() : undefined}
    >
      {/* Title */}
      <h3 className={[styles.title, isNeedsChanges ? styles.titleWarning : ''].filter(Boolean).join(' ')}>
        {title}
      </h3>

      {/* Meta row: status pill + avatar + date */}
      <div className={styles.meta}>
        <StatusPill status={status} label={STATUS_LABELS[status]} size="sm" />
        {(ownerName || ownerAvatarSrc) && (
          <Avatar src={ownerAvatarSrc} name={ownerName} size="md" />
        )}
        {dateLabel && <span className={styles.date}>{dateLabel}</span>}
      </div>

      {/* Description */}
      {showDescription && description && (
        <p className={styles.description}>{description}</p>
      )}

      {/* Artifact row */}
      {hasArtifact && (
        <div className={[styles.artifact, isNeedsChanges ? styles.artifactLight : ''].filter(Boolean).join(' ')}>
          <span className={styles.artifactText}>
            📎&nbsp;&nbsp;{artifactLabel ?? 'Figma artifact attached'}
          </span>
        </div>
      )}

      {/* Divider + footer */}
      {showFooter && (
        <>
          <span className={[styles.divider, isNeedsChanges ? styles.dividerStrong : ''].filter(Boolean).join(' ')} />

          {/* Footer row: counts left, iteration tag right — matches updated DLS */}
          <div className={styles.footer}>
            <div className={[styles.counts, isNeedsChanges ? styles.countsWarning : ''].filter(Boolean).join(' ')}>
              {commentCount !== undefined && (
                <span>{commentCount} {commentCount === 1 ? 'comment' : 'comments'}</span>
              )}
              {decisionCount !== undefined && (
                <span>{decisionCount} {decisionCount === 1 ? 'decision' : 'decisions'}</span>
              )}
            </div>

            {/* Iteration tag — right side of footer */}
            {iterationLabel && (
              <div className={styles.iterationTag}>
                <span className={styles.iterationText}>{iterationLabel}</span>
              </div>
            )}
          </div>
        </>
      )}
    </article>
  );
}
