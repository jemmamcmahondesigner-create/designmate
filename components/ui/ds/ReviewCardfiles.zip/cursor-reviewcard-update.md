# ReviewCard Update — Iteration Tag Moved to Footer

The DLS ReviewCard has been updated. The iteration tag has moved from a
separate Tags row into the footer row itself, right-aligned next to the
comment/decision counts.

Replace `components/ui/ds/ReviewCard.tsx` and `ReviewCard.module.css`
with the new files.

---

## What changed structurally

**Before (old):**
```
[title]
[status pill | avatar | date]
[description]
[artifact row]
[tags row: Navigation tag | Mobile tag]   ← tags here
[divider]
[counts: 3 comments | 1 decision]         ← no iteration
```

**After (new DLS):**
```
[title]
[status pill | avatar | date]
[description]
[artifact row]
[divider]
[counts: 3 comments | 1 decision] [Iteration 1]  ← iteration right-aligned in footer
```

The old `tags` prop (Navigation, Mobile) and `showTags` prop are removed.
The new `iterationLabel` prop carries the iteration string.

---

## Update the barrel export in index.ts

No type name changes — just ensure `iterationLabel` is in the props type:

```ts
export { ReviewCard } from './ReviewCard';
export type { ReviewCardProps, ReviewStatus } from './ReviewCard';
```

---

## Wire iterationLabel from the database

Find every place `ReviewCard` is rendered (likely in the right panel of
project detail and in any reviews list). Pass the iteration from the review
data:

```tsx
<ReviewCard
  title={review.title}
  status={review.status as ReviewStatus}
  ownerName={review.owner_name}
  dateLabel={formatDistanceToNow(new Date(review.updated_at), { addSuffix: true })}
  description={review.description}
  hasArtifact={!!review.artifact_file_name}
  iterationLabel={review.artifact_iteration ?? undefined}  // ← new prop
  commentCount={review.comment_count ?? 0}
  decisionCount={review.decision_count ?? 0}
  onClick={() => openReview(review.id)}
/>
```

`review.artifact_iteration` is the string stored when the review was
created with an artifact (e.g. "Iteration 1"). If null, pass undefined
and no tag renders.

---

## After changes

1. `npx tsc --noEmit` — must pass
2. Pause OneDrive, `rd /s /q .next`, restart dev
3. Check: ReviewCards in the project detail right panel show
   "Iteration 1" tag right-aligned in the footer next to the counts
