'use client';

import { useState, type KeyboardEvent } from 'react';
import { Avatar } from './Avatar';
import { Button } from './Button';
import { Icon } from './Icon';
import { Input } from './Input';
import { Tag } from './Tag';
import styles from './CommentThread.module.css';

// ─── Types ───────────────────────────────────────────────────────────────────
// DLS node 55:235 — 6 variants:
//
// type="feedback"          stakeholder=true  feedbackStatus="Submitted"
//   White card. Avatar + name + timestamp + "Feedback" tag. Body text.
//   Option tag(s). Reply input + Send button.
//
// type="with-reply"        stakeholder=true  feedbackStatus="Reply"
//   White card. Same header. Body text. Option tag(s).
//   Reply block (recessed bg, drill-down icon, reply text + replier details).
//   Reply input + Send button.
//
// type="no-feedback"       stakeholder=false feedbackStatus="Empty"
//   White card. Avatar + name + "Feedback required" label + blocked icon.
//   No body. No reply input.
//
// type="decision-required" stakeholder=false feedbackStatus="Empty"
//   Yellow card. Avatar + name + "Decision Required" label + blocked icon.
//   No body. No reply input. (non-stakeholder view)
//
// type="decision-required" stakeholder=true  feedbackStatus="Empty"
//   Yellow card. Avatar + name + "Decision Required" label + blocked icon.
//   Full-width "Make Decision" primary button.
//
// type="decision"          stakeholder=true  feedbackStatus="Empty"
//   Lilac card. Avatar + name + timestamp + "Decision" success tag.
//   Body text. Option tag(s) in butter style. Reply input + Send button.

export type CommentThreadType =
  | 'feedback'
  | 'with-reply'
  | 'no-feedback'
  | 'decision-required'
  | 'decision';

export interface CommentReply {
  body: string;
  authorName: string;
  authorAvatarSrc?: string;
  timestamp: string;
}

export interface CommentOption {
  label: string;
}

export interface CommentThreadProps {
  type: CommentThreadType;
  /** Whether the current user is the stakeholder/decision-maker for this thread */
  isStakeholder?: boolean;
  authorName: string;
  authorAvatarSrc?: string;
  timestamp?: string;
  body?: string;
  /** Option/artifact tags shown below the body */
  options?: CommentOption[];
  /** Nested reply — shown in with-reply type */
  reply?: CommentReply;
  /** Called when user submits a reply */
  onReply?: (text: string) => void;
  /** Called when "Make Decision" button is clicked */
  onMakeDecision?: () => void;
  className?: string;
}

export function CommentThread({
  type,
  isStakeholder = true,
  authorName,
  authorAvatarSrc,
  timestamp,
  body,
  options = [],
  reply,
  onReply,
  onMakeDecision,
  className,
}: CommentThreadProps) {
  const [replyText, setReplyText] = useState('');

  const handleSend = () => {
    if (!replyText.trim()) return;
    onReply?.(replyText.trim());
    setReplyText('');
  };

  const handleKeyDown = (e: KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  // ─── Determine root styles based on type ──────────────────────────────────
  const isDecisionRequired = type === 'decision-required';
  const isDecision = type === 'decision';
  const isNoFeedback = type === 'no-feedback';
  const isFeedback = type === 'feedback';
  const isWithReply = type === 'with-reply';

  const rootClass = [
    styles.root,
    isDecisionRequired ? styles.rootWarning : '',
    isDecision ? styles.rootLilac : '',
    className ?? '',
  ].filter(Boolean).join(' ');

  // ─── Render ───────────────────────────────────────────────────────────────

  return (
    <article className={rootClass}>

      {/* ── Header row ── */}
      <div className={styles.header}>
        {/* Avatar */}
        <Avatar src={authorAvatarSrc} name={authorName} size="md" />

        {/* Name + timestamp (feedback, with-reply, decision) */}
        {(isFeedback || isWithReply || isDecision) && (
          <>
            <span className={styles.authorName}>{authorName}</span>
            {timestamp && <span className={styles.dot}>·</span>}
            {timestamp && <span className={styles.timestamp}>{timestamp}</span>}
            {/* Type tag — right side */}
            {isFeedback || isWithReply ? (
              <Tag label="Feedback" variant="default" size="sm" />
            ) : isDecision ? (
              <Tag label="Decision" variant="success" size="sm" />
            ) : null}
          </>
        )}

        {/* Name + status label (no-feedback, decision-required) */}
        {(isNoFeedback || isDecisionRequired) && (
          <>
            <span className={styles.authorNameFull}>{authorName}</span>
            <span className={isDecisionRequired ? styles.statusLabelWarning : styles.statusLabel}>
              {isDecisionRequired ? 'Decision Required' : 'Feedback required'}
            </span>
            <span className={styles.blockedIcon} aria-hidden="true">
              <Icon name="status-blocked" size={16} color={isDecisionRequired ? '#7a5500' : '#7a5500'} />
            </span>
          </>
        )}
      </div>

      {/* ── Body text ── */}
      {body && (isFeedback || isWithReply || isDecision) && (
        <p className={styles.body}>{body}</p>
      )}

      {/* ── Option tags ── */}
      {options.length > 0 && (isFeedback || isWithReply || isDecision) && (
        <div className={styles.options}>
          {options.map((opt, i) => (
            <Tag
              key={i}
              label={opt.label}
              variant={isDecision ? 'butter' : 'brand'}
              size="sm"
            />
          ))}
        </div>
      )}

      {/* ── Nested reply block (with-reply only) ── */}
      {isWithReply && reply && (
        <div className={styles.replyBlock}>
          <span className={styles.replyIcon} aria-hidden="true">
            <Icon name="drill-down" size={20} />
          </span>
          <div className={styles.replyContent}>
            <p className={styles.replyBody}>{reply.body}</p>
            <div className={styles.replyMeta}>
              <Avatar src={reply.authorAvatarSrc} name={reply.authorName} size="md" />
              <span className={styles.replyAuthor}>{reply.authorName}</span>
              <span className={styles.dot}>·</span>
              <span className={styles.timestamp}>{reply.timestamp}</span>
            </div>
          </div>
        </div>
      )}

      {/* ── Reply input row (feedback, with-reply, decision) ── */}
      {(isFeedback || isWithReply || isDecision) && onReply && (
        <div className={styles.replyRow}>
          <input
            type="text"
            className={styles.replyInput}
            placeholder="Reply..."
            value={replyText}
            onChange={e => setReplyText(e.target.value)}
            onKeyDown={handleKeyDown}
            aria-label="Write a reply"
          />
          <Button
            variant="secondary"
            size="sm"
            label="Send"
            onClick={handleSend}
            disabled={!replyText.trim()}
          />
        </div>
      )}

      {/* ── Make Decision button (decision-required + stakeholder) ── */}
      {isDecisionRequired && isStakeholder && (
        <Button
          variant="primary"
          size="sm"
          label="Make Decision"
          onClick={onMakeDecision}
          className={styles.makeDecisionBtn}
        />
      )}

    </article>
  );
}
