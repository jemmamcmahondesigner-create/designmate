'use client';

import { Avatar } from './Avatar';
import { Button } from './Button';
import { Icon } from './Icon';
import { StatusPill } from './StatusPill';
import { Tag } from './Tag';
import styles from './DecisionCard.module.css';

// ─── DecisionCard ─────────────────────────────────────────────────────────────
// DLS node 55:195 (frame) → 55:110 (approved, Large)
//
// Structure:
//   [Recessed header: "DECISION STATUS" label + StatusPill]
//   [Content area:]
//     Option tags (brand/blush style, showing chosen direction)
//     Decision text body
//     Owner row: avatar + name + timestamp + kebab button
//     Trade-off block (optional): butter border, "TRADE-OFF ACCEPTED" overline,
//       AI stars icon, trade-off note text

export type DecisionStatus =
  | 'approved'
  | 'needs-changes'
  | 'in-review'
  | 'blocked'
  | 'draft';

export interface DecisionOption {
  label: string;
}

export interface DecisionCardProps {
  status: DecisionStatus;
  /** Chosen option tags shown below the status header */
  options?: DecisionOption[];
  decisionText: string;
  ownerName: string;
  ownerAvatarSrc?: string;
  dateLabel?: string;
  /** Whether to show the trade-off accepted block */
  showTradeOff?: boolean;
  tradeOffNote?: string;
  /** Whether trade-off was AI generated */
  tradeOffIsAI?: boolean;
  onKebab?: () => void;
  className?: string;
}

const STATUS_LABELS: Record<DecisionStatus, string> = {
  approved: 'Approved',
  'needs-changes': 'Needs Changes',
  'in-review': 'In Review',
  blocked: 'Blocked',
  draft: 'Draft',
};

export function DecisionCard({
  status,
  options = [],
  decisionText,
  ownerName,
  ownerAvatarSrc,
  dateLabel,
  showTradeOff = false,
  tradeOffNote,
  tradeOffIsAI = true,
  onKebab,
  className,
}: DecisionCardProps) {
  return (
    <article className={[styles.root, className ?? ''].filter(Boolean).join(' ')}>

      {/* ── Recessed header ── */}
      <div className={styles.statusHeader}>
        <span className={styles.statusLabel}>Decision Status</span>
        <StatusPill
          status={status}
          label={STATUS_LABELS[status]}
          size="md"
          prominence="high"
        />
      </div>

      {/* ── Content area ── */}
      <div className={styles.content}>

        {/* Option tags */}
        {options.length > 0 && (
          <div className={styles.options}>
            {options.map((opt, i) => (
              <Tag key={i} label={opt.label} variant="brand" size="sm" />
            ))}
          </div>
        )}

        {/* Decision text + owner row */}
        <div className={styles.textBlock}>
          <p className={styles.decisionText}>{decisionText}</p>

          <div className={styles.ownerRow}>
            {/* Owner details */}
            <div className={styles.ownerDetails}>
              <Avatar src={ownerAvatarSrc} name={ownerName} size="md" />
              <span className={styles.ownerName}>{ownerName}</span>
              {dateLabel && <span className={styles.dot}>·</span>}
              {dateLabel && <span className={styles.timestamp}>{dateLabel}</span>}
            </div>

            {/* Kebab menu button */}
            {onKebab && (
              <button
                type="button"
                className={styles.kebabBtn}
                onClick={onKebab}
                aria-label="More options"
              >
                <Icon name="kebab" size={14} />
              </button>
            )}
          </div>
        </div>

        {/* Trade-off block */}
        {showTradeOff && (
          <div className={styles.tradeOff}>
            <div className={styles.tradeOffHeader}>
              <span className={styles.tradeOffLabel}>Trade-off Accepted</span>
              {tradeOffIsAI && (
                <span className={styles.aiIcon} aria-label="AI generated" title="AI generated">
                  <Icon name="ai-stars" size={20} color="#998c82" />
                </span>
              )}
            </div>
            {tradeOffNote && (
              <p className={styles.tradeOffNote}>{tradeOffNote}</p>
            )}
          </div>
        )}

      </div>
    </article>
  );
}
