'use client';

import {
  useState,
  useRef,
  useId,
  useEffect,
  type KeyboardEvent,
  type ReactNode,
} from 'react';
import { Icon } from './Icon';
import styles from './Select.module.css';

export type SelectSize = 'sm' | 'md' | 'lg';
export type SelectState = 'default' | 'hover' | 'focused' | 'filled' | 'error' | 'disabled';

export interface SelectOption {
  value: string;
  label: string;
  disabled?: boolean;
}

export interface SelectProps {
  options: SelectOption[];
  value?: string;
  onChange?: (value: string) => void;
  placeholder?: string;
  label?: string;
  helperText?: string;
  errorText?: string;
  size?: SelectSize;
  disabled?: boolean;
  /** Renders the menu open immediately (for searchable/autocomplete UX) */
  searchable?: boolean;
  id?: string;
  name?: string;
  className?: string;
}

export function Select({
  options,
  value,
  onChange,
  placeholder = 'Select an option',
  label,
  helperText,
  errorText,
  size = 'sm',
  disabled = false,
  searchable = false,
  id: idProp,
  name,
  className,
}: SelectProps) {
  const autoId = useId();
  const id = idProp ?? autoId;
  const [open, setOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const triggerRef = useRef<HTMLButtonElement>(null);
  const menuRef = useRef<HTMLUListElement>(null);

  const selectedOption = options.find(o => o.value === value);
  const displayLabel = selectedOption?.label ?? '';
  const hasError = !!errorText;
  const isFilled = !!value;

  const filteredOptions = searchable && searchTerm
    ? options.filter(o => o.label.toLowerCase().includes(searchTerm.toLowerCase()))
    : options;

  // Close on outside click
  useEffect(() => {
    if (!open) return;
    const handler = (e: MouseEvent) => {
      if (
        triggerRef.current?.contains(e.target as Node) ||
        menuRef.current?.contains(e.target as Node)
      ) return;
      setOpen(false);
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, [open]);

  const handleSelect = (optValue: string) => {
    onChange?.(optValue);
    setOpen(false);
    setSearchTerm('');
    triggerRef.current?.focus();
  };

  const handleKeyDown = (e: KeyboardEvent) => {
    if (e.key === 'Escape') { setOpen(false); triggerRef.current?.focus(); }
    if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); setOpen(o => !o); }
    if (e.key === 'ArrowDown') { e.preventDefault(); setOpen(true); }
  };

  const controlClass = [
    styles.control,
    styles[`size-${size}`],
    hasError ? styles.error : '',
    disabled ? styles.disabled : '',
    open ? styles.open : '',
    isFilled && !hasError ? styles.filled : '',
  ].filter(Boolean).join(' ');

  const labelClass = [
    styles.label,
    hasError ? styles.labelError : '',
    disabled ? styles.labelDisabled : '',
  ].filter(Boolean).join(' ');

  return (
    <div className={[styles.root, className ?? ''].filter(Boolean).join(' ')}>
      {label && (
        <label htmlFor={id} className={labelClass}>
          {label}
        </label>
      )}

      {/* Hidden native select for form submission */}
      <select
        name={name}
        value={value ?? ''}
        disabled={disabled}
        aria-hidden="true"
        tabIndex={-1}
        style={{ display: 'none' }}
        onChange={e => onChange?.(e.target.value)}
      >
        <option value="" />
        {options.map(o => (
          <option key={o.value} value={o.value} disabled={o.disabled}>{o.label}</option>
        ))}
      </select>

      {/* Custom control */}
      <div className={styles.wrapper}>
        <button
          ref={triggerRef}
          id={id}
          type="button"
          role="combobox"
          aria-haspopup="listbox"
          aria-expanded={open}
          aria-disabled={disabled}
          disabled={disabled}
          className={controlClass}
          onClick={() => !disabled && setOpen(o => !o)}
          onKeyDown={handleKeyDown}
        >
          {searchable && open ? (
            <input
              className={styles.searchInput}
              value={searchTerm}
              placeholder={displayLabel || placeholder}
              onChange={e => setSearchTerm(e.target.value)}
              onClick={e => e.stopPropagation()}
              autoFocus
              aria-label="Search options"
            />
          ) : (
            <span className={displayLabel ? styles.valueText : styles.placeholderText}>
              {displayLabel || placeholder}
            </span>
          )}
          <Icon
            name="chevron-down"
            size={size === 'sm' ? 14 : size === 'md' ? 16 : 18}
            className={[styles.chevron, open ? styles.chevronOpen : ''].filter(Boolean).join(' ')}
            aria-hidden="true"
          />
        </button>

        {/* Dropdown */}
        {open && (
          <ul
            ref={menuRef}
            role="listbox"
            aria-label={label ?? 'Options'}
            className={styles.menu}
          >
            {filteredOptions.length === 0 && (
              <li className={styles.noResults}>No options found</li>
            )}
            {filteredOptions.map(option => (
              <li
                key={option.value}
                role="option"
                aria-selected={option.value === value}
                aria-disabled={option.disabled}
                className={[
                  styles.menuItem,
                  option.value === value ? styles.menuItemSelected : '',
                  option.disabled ? styles.menuItemDisabled : '',
                ].filter(Boolean).join(' ')}
                onMouseDown={e => e.preventDefault()}
                onClick={() => !option.disabled && handleSelect(option.value)}
              >
                {option.label}
                {option.value === value && (
                  <Icon name="check" size={14} className={styles.checkIcon} />
                )}
              </li>
            ))}
          </ul>
        )}
      </div>

      {/* Helper / error text */}
      {hasError && (
        <p className={styles.errorText} role="alert">{errorText}</p>
      )}
      {!hasError && helperText && (
        <p className={styles.helperText}>{helperText}</p>
      )}
    </div>
  );
}
