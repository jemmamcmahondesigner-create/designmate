'use client';

import { StatusPill } from './StatusPill';
import { Tag } from './Tag';
import { Avatar } from './Avatar';
import styles from './ProductCard.module.css';

export interface ProductCardContributor {
  name: string;
  avatarSrc?: string;
}

export interface ProductCardProps {
  title: string;
  /** Project status pill */
  statusLabel?: string;
  reviewCount?: number;
  decisionCount?: number;
  description?: string;
  /** Category / client tag shown bottom-left */
  tagLabel?: string;
  contributors?: ProductCardContributor[];
  onClick?: () => void;
  className?: string;
}

export function ProductCard({
  title,
  statusLabel = 'Active',
  reviewCount,
  decisionCount,
  description,
  tagLabel,
  contributors = [],
  onClick,
  className,
}: ProductCardProps) {
  const rootClass = [
    styles.root,
    onClick ? styles.clickable : '',
    className ?? '',
  ].filter(Boolean).join(' ');

  return (
    <article
      className={rootClass}
      onClick={onClick}
      role={onClick ? 'button' : undefined}
      tabIndex={onClick ? 0 : undefined}
      onKeyDown={onClick ? e => e.key === 'Enter' && onClick() : undefined}
    >
      {/* Title */}
      <h3 className={styles.title}>{title}</h3>

      {/* Status row */}
      <div className={styles.meta}>
        <StatusPill
          status="approved"
          label={statusLabel}
          size="sm"
          prominence="high"
        />
        {reviewCount !== undefined && (
          <span className={styles.count}>{reviewCount} {reviewCount === 1 ? 'review' : 'reviews'}</span>
        )}
        {decisionCount !== undefined && (
          <span className={styles.count}>{decisionCount} {decisionCount === 1 ? 'decision' : 'decisions'}</span>
        )}
      </div>

      {/* Description */}
      {description && (
        <p className={styles.description}>{description}</p>
      )}

      {/* Footer: tag + avatars */}
      <div className={styles.footer}>
        {tagLabel && (
          <Tag label={tagLabel} variant="butter" size="sm" />
        )}
        {contributors.length > 0 && (
          <div className={styles.avatarGroup}>
            {contributors.slice(0, 4).map((c, i) => (
              <div
                key={i}
                className={styles.avatarWrap}
                style={{ zIndex: 4 - i }}
              >
                <Avatar src={c.avatarSrc} name={c.name} size="md" />
              </div>
            ))}
          </div>
        )}
      </div>
    </article>
  );
}
