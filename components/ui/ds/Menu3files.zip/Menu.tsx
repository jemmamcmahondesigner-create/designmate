'use client';

import {
  useEffect,
  useRef,
  type ReactNode,
  type KeyboardEvent,
} from 'react';
import { Icon, type IconName } from './Icon';
import { Avatar } from './Avatar';
import { Checkbox } from './Checkbox';
import styles from './Menu.module.css';

// ─── Types ────────────────────────────────────────────────────────────────────

export type MenuType = 'dropdown' | 'context-menu' | 'action-menu' | 'multi-select';
export type MenuItemType = 'icon' | 'avatar';
export type MenuFooterType = 'link' | 'delete';

// ─── MenuFooter ───────────────────────────────────────────────────────────────
// DLS node 265:4560
// type="link"   — brand colour, plus icon, create/add action
// type="delete" — red text, trash icon, destructive action
// Sits below a divider at the bottom of action-menu and multi-select+action types.
// hover:link   = #ede8e0 (interactive/hover/surface-strong)
// hover:delete = #fceaea (feedback/error/bg)

export interface MenuFooterProps {
  type: MenuFooterType;
  label?: string;
  onClick?: () => void;
}

export function MenuFooter({ type, label, onClick }: MenuFooterProps) {
  const isDelete = type === 'delete';
  const defaultLabel = isDelete ? 'Delete' : 'Link';

  return (
    <li
      role="menuitem"
      tabIndex={0}
      className={[styles.footer, isDelete ? styles.footerDelete : styles.footerLink].join(' ')}
      onClick={onClick}
      onKeyDown={(e: KeyboardEvent) => {
        if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); onClick?.(); }
      }}
    >
      <span className={styles.footerIcon} aria-hidden="true">
        <Icon name={isDelete ? 'trash' : 'plus'} size={16} />
      </span>
      <span className={styles.footerLabel}>{label ?? defaultLabel}</span>
    </li>
  );
}

// ─── MenuItem ─────────────────────────────────────────────────────────────────
// DLS node 120:3899
// type="icon"   — leading DS icon (default)
// type="avatar" — avatar image instead of icon
// checkbox=true — shows DS Checkbox before the icon/avatar (multi-select mode)
// active state  — blush bg (#f5eaec), brand text, trailing check icon (icon type)
//               or checked checkbox (checkbox=true type)

export interface MenuItemProps {
  label: string;
  /** Icon type: leading DS icon */
  icon?: IconName;
  /** Avatar type: shows avatar image */
  avatarSrc?: string;
  avatarName?: string;
  /** Whether this item has a checkbox (multi-select mode) */
  checkbox?: boolean;
  /** Active/selected state */
  active?: boolean;
  disabled?: boolean;
  /** Divider rendered above this item */
  dividerAbove?: boolean;
  onClick?: () => void;
}

export function MenuItem({
  label,
  icon,
  avatarSrc,
  avatarName,
  checkbox = false,
  active = false,
  disabled = false,
  dividerAbove = false,
  onClick,
}: MenuItemProps) {
  const hasAvatar = !!(avatarSrc || avatarName);
  const iconColor = active ? '#6b1e2e' : '#6b5e55';

  const itemClass = [
    styles.item,
    active ? styles.itemActive : '',
    disabled ? styles.itemDisabled : '',
  ].filter(Boolean).join(' ');

  return (
    <>
      {dividerAbove && <div className={styles.divider} role="separator" />}
      <li
        role={checkbox ? 'menuitemcheckbox' : 'menuitem'}
        aria-checked={checkbox ? active : undefined}
        aria-selected={!checkbox && active}
        aria-disabled={disabled}
        tabIndex={disabled ? -1 : 0}
        className={itemClass}
        onClick={() => !disabled && onClick?.()}
        onKeyDown={(e: KeyboardEvent) => {
          if ((e.key === 'Enter' || e.key === ' ') && !disabled) {
            e.preventDefault();
            onClick?.();
          }
        }}
      >
        {/* Checkbox — multi-select mode */}
        {checkbox && (
          <span className={styles.itemCheckbox} aria-hidden="true">
            <Checkbox checked={active} onChange={() => {}} />
          </span>
        )}

        {/* Leading: avatar or icon */}
        {hasAvatar ? (
          <span className={styles.itemAvatar}>
            <Avatar src={avatarSrc} name={avatarName} size="md" />
          </span>
        ) : icon ? (
          <span className={styles.itemIcon} aria-hidden="true">
            <Icon name={icon} size={16} color={iconColor} />
          </span>
        ) : null}

        {/* Label */}
        <span className={[styles.itemLabel, active && !checkbox ? styles.itemLabelActive : ''].filter(Boolean).join(' ')}>
          {label}
        </span>

        {/* Trailing check — active, no checkbox */}
        {active && !checkbox && (
          <span className={styles.itemCheck} aria-hidden="true">
            <Icon name="check" size={16} color="#6b1e2e" />
          </span>
        )}
      </li>
    </>
  );
}

// ─── Menu ─────────────────────────────────────────────────────────────────────
// DLS node 112:163
// Types:
//   dropdown      — plain option list
//   context-menu  — with active/selected state + check
//   action-menu   — context-menu + MenuFooter (delete) at bottom
//   multi-select  — checkbox + avatar items; optional MenuFooter (link) at bottom
//
// Width: min-width 240px, fills trigger element width (set by parent/wrapper)
// Position: 4px below trigger

export interface MenuProps {
  open: boolean;
  onClose: () => void;
  children: ReactNode;
  type?: MenuType;
  /** Shows a footer action (MenuFooter) below a divider */
  footerAction?: MenuFooterProps;
  anchorRef?: React.RefObject<HTMLElement>;
  align?: 'left' | 'right';
  'aria-label'?: string;
  className?: string;
}

export function Menu({
  open,
  onClose,
  children,
  type = 'dropdown',
  footerAction,
  anchorRef,
  align = 'left',
  'aria-label': ariaLabel = 'Menu',
  className,
}: MenuProps) {
  const menuRef = useRef<HTMLUListElement>(null);

  // Close on outside click
  useEffect(() => {
    if (!open) return;
    const handler = (e: MouseEvent) => {
      if (menuRef.current?.contains(e.target as Node)) return;
      if (anchorRef?.current?.contains(e.target as Node)) return;
      onClose();
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, [open, onClose, anchorRef]);

  // Escape + arrow key navigation
  useEffect(() => {
    if (!open) return;
    const handler = (e: globalThis.KeyboardEvent) => {
      if (e.key === 'Escape') { onClose(); return; }
      if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
        e.preventDefault();
        const items = Array.from(
          menuRef.current?.querySelectorAll<HTMLElement>(
            '[role="menuitem"],[role="menuitemcheckbox"]:not([aria-disabled="true"])'
          ) ?? []
        );
        const idx = items.indexOf(document.activeElement as HTMLElement);
        const next = e.key === 'ArrowDown'
          ? items[Math.min(idx + 1, items.length - 1)]
          : items[Math.max(idx - 1, 0)];
        next?.focus();
      }
    };
    document.addEventListener('keydown', handler);
    return () => document.removeEventListener('keydown', handler);
  }, [open, onClose]);

  // Auto-focus first item on open
  useEffect(() => {
    if (!open) return;
    const t = setTimeout(() => {
      const first = menuRef.current?.querySelector<HTMLElement>(
        '[role="menuitem"],[role="menuitemcheckbox"]:not([aria-disabled="true"])'
      );
      first?.focus();
    }, 10);
    return () => clearTimeout(t);
  }, [open]);

  if (!open) return null;

  const hasFooter = !!footerAction;
  const menuClass = [
    styles.menu,
    align === 'right' ? styles.alignRight : styles.alignLeft,
    hasFooter ? styles.overflow : '',
    className ?? '',
  ].filter(Boolean).join(' ');

  return (
    <ul
      ref={menuRef}
      role="menu"
      aria-label={ariaLabel}
      className={menuClass}
    >
      {/* Main items */}
      {hasFooter ? (
        <div className={styles.itemsGroup}>
          {children}
        </div>
      ) : children}

      {/* Footer action */}
      {footerAction && (
        <>
          <div className={styles.divider} role="separator" />
          <MenuFooter {...footerAction} />
        </>
      )}
    </ul>
  );
}
