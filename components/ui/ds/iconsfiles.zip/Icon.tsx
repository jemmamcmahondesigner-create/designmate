'use client';

import { type SVGProps } from 'react';

// ─── Icon component ───────────────────────────────────────────────────────────
// Single entry point. Usage:
//   <Icon name="plus" size={16} color="currentColor" />
//   <Icon name="nav-reviews" size={20} aria-label="Reviews" />

export type IconName =
  // Nav
  | 'nav-home'
  | 'nav-mark'
  | 'nav-reviews'
  | 'nav-decisions'
  | 'nav-drafts'
  | 'nav-archive'
  | 'nav-settings'
  // Action
  | 'plus'
  | 'minus'
  | 'edit'
  | 'trash'
  | 'share'
  | 'export'
  | 'close'
  | 'check'
  | 'send'
  | 'notification'
  | 'stretch'
  | 'drill-down'
  | 'close-drawer'
  | 'open-drawer'
  | 'kebab'
  | 'filter'
  | 'upload'
  | 'contributor'
  // Status
  | 'status-draft'
  | 'status-in-review'
  | 'status-approved'
  | 'status-blocked'
  | 'status-comment'
  | 'status-decision'
  | 'ai-stars'
  // Content
  | 'attach'
  | 'link'
  | 'tradeoff'
  | 'chevron-down'
  | 'chevron-up'
  | 'chevron-right'
  | 'chevron-left'
  | 'search'
  | 'info'
  | 'dot';

export interface IconProps extends SVGProps<SVGSVGElement> {
  name: IconName;
  size?: number;
  color?: string;
  'aria-label'?: string;
}

export function Icon({ name, size = 24, color = 'currentColor', style, ...rest }: IconProps) {
  const IconComponent = ICONS[name];
  if (!IconComponent) return null;
  return (
    <IconComponent
      width={size}
      height={size}
      fill={color}
      aria-hidden={rest['aria-label'] ? undefined : true}
      style={{ flexShrink: 0, display: 'inline-block', ...style }}
      {...rest}
    />
  );
}

// ─── Icon map ─────────────────────────────────────────────────────────────────

type SvgIcon = (props: SVGProps<SVGSVGElement>) => JSX.Element;

const ICONS: Record<IconName, SvgIcon> = {

  // ── NAV ────────────────────────────────────────────────────────────────────

  'nav-home': (p) => (
    <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" {...p}>
      <path d="M3 9.5L12 3l9 6.5V20a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V9.5Z" strokeWidth="1.5" stroke="currentColor" fill="none"/>
      <path d="M9 21v-8h6v8" strokeWidth="1.5" stroke="currentColor" fill="none" strokeLinecap="round"/>
    </svg>
  ),

  'nav-mark': (p) => (
    <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" {...p}>
      {/* DesignMate wordmark icon — 6 pill shapes forming a D letterform */}
      <rect x="4" y="4" width="7" height="3.5" rx="1.75" fill="currentColor"/>
      <rect x="4" y="16.5" width="7" height="3.5" rx="1.75" fill="currentColor"/>
      <rect x="4" y="9.25" width="4" height="2.5" rx="1.25" fill="currentColor"/>
      <rect x="13" y="9.25" width="4" height="2.5" rx="1.25" fill="currentColor"/>
      <rect x="4" y="12.25" width="4" height="2.5" rx="1.25" fill="currentColor"/>
      <rect x="13" y="12.25" width="4" height="2.5" rx="1.25" fill="currentColor"/>
    </svg>
  ),

  'nav-reviews': (p) => (
    <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" {...p}>
      <path d="M3 5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v11a2 2 0 0 1-2 2H8l-5 4V5Z" strokeWidth="1.5" stroke="currentColor" fill="none" strokeLinejoin="round"/>
      <path d="M7 9h10M7 13h6" strokeWidth="1.5" stroke="currentColor" strokeLinecap="round"/>
    </svg>
  ),

  'nav-decisions': (p) => (
    <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" {...p}>
      <path d="M9 12l2 2 4-4" strokeWidth="1.5" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" fill="none"/>
      <circle cx="12" cy="12" r="9" strokeWidth="1.5" stroke="currentColor" fill="none"/>
    </svg>
  ),

  'nav-drafts': (p) => (
    <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" {...p}>
      <path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8l-5-5Z" strokeWidth="1.5" stroke="currentColor" fill="none"/>
      <path d="M14 3v5h5M8 13h8M8 17h5" strokeWidth="1.5" stroke="currentColor" strokeLinecap="round"/>
    </svg>
  ),

  'nav-archive': (p) => (
    <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" {...p}>
      <rect x="3" y="4" width="18" height="4" rx="1" strokeWidth="1.5" stroke="currentColor" fill="none"/>
      <path d="M5 8v10a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8" strokeWidth="1.5" stroke="currentColor" fill="none"/>
      <path d="M10 12h4" strokeWidth="1.5" stroke="currentColor" strokeLinecap="round"/>
    </svg>
  ),

  'nav-settings': (p) => (
    <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" {...p}>
      <circle cx="12" cy="12" r="3" strokeWidth="1.5" stroke="currentColor" fill="none"/>
      <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1Z" strokeWidth="1.5" stroke="currentColor" fill="none"/>
    </svg>
  ),

  // ── ACTION ──────────────────────────────────────────────────────────────────

  'plus': (p) => (
    <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" {...p}>
      <path d="M12 5v14M5 12h14" strokeWidth="1.75" stroke="currentColor" strokeLinecap="round" fill="none"/>
    </svg>
  ),

  'minus': (p) => (
    <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" {...p}>
      <path d="M5 12h14" strokeWidth="1.75" stroke="currentColor" strokeLinecap="round" fill="none"/>
    </svg>
  ),

  'edit': (p) => (
    <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" {...p}>
      <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" strokeWidth="1.5" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" fill="none"/>
      <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5Z" strokeWidth="1.5" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" fill="none"/>
    </svg>
  ),

  'trash': (p) => (
    <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" {...p}>
      <path d="M3 6h18M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" strokeWidth="1.5" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" fill="none"/>
    </svg>
  ),

  'share': (p) => (
    <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" {...p}>
      <circle cx="18" cy="5" r="3" strokeWidth="1.5" stroke="currentColor" fill="none"/>
      <circle cx="6" cy="12" r="3" strokeWidth="1.5" stroke="currentColor" fill="none"/>
      <circle cx="18" cy="19" r="3" strokeWidth="1.5" stroke="currentColor" fill="none"/>
      <path d="m8.59 13.51 6.83 3.98M15.41 6.51l-6.82 3.98" strokeWidth="1.5" stroke="currentColor" fill="none"/>
    </svg>
  ),

  'export': (p) => (
    <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" {...p}>
      <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M7 10l5 5 5-5M12 15V3" strokeWidth="1.5" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" fill="none"/>
    </svg>
  ),

  'close': (p) => (
    <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" {...p}>
      <path d="M18 6 6 18M6 6l12 12" strokeWidth="1.75" stroke="currentColor" strokeLinecap="round" fill="none"/>
    </svg>
  ),

  'check': (p) => (
    <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" {...p}>
      <path d="M20 6 9 17l-5-5" strokeWidth="1.75" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" fill="none"/>
    </svg>
  ),

  'send': (p) => (
    <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" {...p}>
      <path d="M22 2 11 13M22 2 15 22l-4-9-9-4 20-7Z" strokeWidth="1.5" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" fill="none"/>
    </svg>
  ),

  'notification': (p) => (
    <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" {...p}>
      <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9M13.73 21a2 2 0 0 1-3.46 0" strokeWidth="1.5" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" fill="none"/>
    </svg>
  ),

  'stretch': (p) => (
    <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" {...p}>
      <path d="M15 3h6v6M9 21H3v-6M21 3l-7 7M3 21l7-7" strokeWidth="1.5" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" fill="none"/>
    </svg>
  ),

  'drill-down': (p) => (
    <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" {...p}>
      <path d="M8 4v8l8 4" strokeWidth="1.5" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" fill="none"/>
      <path d="M3 12h5" strokeWidth="1.5" stroke="currentColor" strokeLinecap="round" fill="none"/>
    </svg>
  ),

  'close-drawer': (p) => (
    <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" {...p}>
      <rect x="3" y="3" width="18" height="18" rx="2" strokeWidth="1.5" stroke="currentColor" fill="none"/>
      <path d="M9 3v18M14 9l-3 3 3 3" strokeWidth="1.5" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" fill="none"/>
    </svg>
  ),

  'open-drawer': (p) => (
    <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" {...p}>
      <rect x="3" y="3" width="18" height="18" rx="2" strokeWidth="1.5" stroke="currentColor" fill="none"/>
      <path d="M15 3v18M10 9l3 3-3 3" strokeWidth="1.5" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" fill="none"/>
    </svg>
  ),

  'kebab': (p) => (
    <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" {...p}>
      <circle cx="12" cy="5" r="1.5" fill="currentColor"/>
      <circle cx="12" cy="12" r="1.5" fill="currentColor"/>
      <circle cx="12" cy="19" r="1.5" fill="currentColor"/>
    </svg>
  ),

  'filter': (p) => (
    <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" {...p}>
      <path d="M22 3H2l8 9.46V19l4 2v-8.54L22 3Z" strokeWidth="1.5" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" fill="none"/>
    </svg>
  ),

  'upload': (p) => (
    <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" {...p}>
      <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M17 8l-5-5-5 5M12 3v12" strokeWidth="1.5" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" fill="none"/>
    </svg>
  ),

  'contributor': (p) => (
    <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" {...p}>
      <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" strokeWidth="1.5" stroke="currentColor" strokeLinecap="round" fill="none"/>
      <circle cx="9" cy="7" r="4" strokeWidth="1.5" stroke="currentColor" fill="none"/>
      <path d="M23 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75" strokeWidth="1.5" stroke="currentColor" strokeLinecap="round" fill="none"/>
    </svg>
  ),

  // ── STATUS ──────────────────────────────────────────────────────────────────

  'status-draft': (p) => (
    <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" {...p}>
      <path d="M12 2a10 10 0 1 0 0 20A10 10 0 0 0 12 2Z" strokeWidth="1.5" stroke="currentColor" strokeDasharray="3 2" fill="none"/>
    </svg>
  ),

  'status-in-review': (p) => (
    <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" {...p}>
      <circle cx="12" cy="12" r="10" strokeWidth="1.5" stroke="currentColor" fill="none"/>
      <path d="M12 8v4l3 3" strokeWidth="1.5" stroke="currentColor" strokeLinecap="round" fill="none"/>
    </svg>
  ),

  'status-approved': (p) => (
    <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" {...p}>
      <circle cx="12" cy="12" r="10" strokeWidth="1.5" stroke="currentColor" fill="none"/>
      <path d="M8 12l3 3 5-5" strokeWidth="1.75" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" fill="none"/>
    </svg>
  ),

  'status-blocked': (p) => (
    <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" {...p}>
      <path d="M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0Z" strokeWidth="1.5" stroke="currentColor" fill="none"/>
      <line x1="12" y1="9" x2="12" y2="13" strokeWidth="1.75" stroke="currentColor" strokeLinecap="round"/>
      <circle cx="12" cy="17" r="1" fill="currentColor"/>
    </svg>
  ),

  'status-comment': (p) => (
    <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" {...p}>
      <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2Z" strokeWidth="1.5" stroke="currentColor" fill="none"/>
    </svg>
  ),

  'status-decision': (p) => (
    <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" {...p}>
      <path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2Z" strokeWidth="1.5" stroke="currentColor" fill="none"/>
      <path d="M9 12l2 2 4-4" strokeWidth="1.5" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" fill="none"/>
    </svg>
  ),

  'ai-stars': (p) => (
    <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" {...p}>
      <path d="M12 2l2.09 6.26L20.5 10l-6.41 1.74L12 18l-2.09-6.26L3.5 10l6.41-1.74L12 2Z" fill="currentColor" opacity="0.7"/>
      <path d="M19 2l1 3 3 1-3 1-1 3-1-3-3-1 3-1 1-3Z" fill="currentColor" opacity="0.5"/>
    </svg>
  ),

  // ── CONTENT ─────────────────────────────────────────────────────────────────

  'attach': (p) => (
    <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" {...p}>
      <path d="M21.44 11.05l-9.19 9.19a6 6 0 0 1-8.49-8.49l9.19-9.19a4 4 0 0 1 5.66 5.66l-9.2 9.19a2 2 0 0 1-2.83-2.83l8.49-8.48" strokeWidth="1.5" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" fill="none"/>
    </svg>
  ),

  'link': (p) => (
    <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" {...p}>
      <path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71" strokeWidth="1.5" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" fill="none"/>
      <path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71" strokeWidth="1.5" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" fill="none"/>
    </svg>
  ),

  'tradeoff': (p) => (
    <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" {...p}>
      <path d="M8 3H2l7 9H2M16 3h6l-7 9h7" strokeWidth="1.5" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" fill="none"/>
      <path d="M12 12v9M9 21h6" strokeWidth="1.5" stroke="currentColor" strokeLinecap="round" fill="none"/>
    </svg>
  ),

  'chevron-down': (p) => (
    <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" {...p}>
      <path d="M6 9l6 6 6-6" strokeWidth="1.75" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" fill="none"/>
    </svg>
  ),

  'chevron-up': (p) => (
    <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" {...p}>
      <path d="M18 15l-6-6-6 6" strokeWidth="1.75" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" fill="none"/>
    </svg>
  ),

  'chevron-right': (p) => (
    <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" {...p}>
      <path d="M9 18l6-6-6-6" strokeWidth="1.75" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" fill="none"/>
    </svg>
  ),

  'chevron-left': (p) => (
    <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" {...p}>
      <path d="M15 18l-6-6 6-6" strokeWidth="1.75" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" fill="none"/>
    </svg>
  ),

  'search': (p) => (
    <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" {...p}>
      <circle cx="11" cy="11" r="8" strokeWidth="1.5" stroke="currentColor" fill="none"/>
      <path d="m21 21-4.35-4.35" strokeWidth="1.75" stroke="currentColor" strokeLinecap="round" fill="none"/>
    </svg>
  ),

  'info': (p) => (
    <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" {...p}>
      <circle cx="12" cy="12" r="10" strokeWidth="1.5" stroke="currentColor" fill="none"/>
      <line x1="12" y1="16" x2="12" y2="12" strokeWidth="1.75" stroke="currentColor" strokeLinecap="round"/>
      <circle cx="12" cy="8.5" r="1" fill="currentColor"/>
    </svg>
  ),

  'dot': (p) => (
    <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" {...p}>
      <circle cx="12" cy="12" r="4" fill="currentColor"/>
    </svg>
  ),
};
