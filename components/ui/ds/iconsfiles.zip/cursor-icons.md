# Icon System — Install + Global Replacement

The DLS icon set has been extracted as inline SVG React components.
This eliminates all Figma CDN image URLs (which expire in 7 days) and
gives us scalable, colour-inheriting, accessible icons.

Run `npx tsc --noEmit` after completing all sections.

---

## Why SVG inline, not exported PNGs

The Figma icons page is labelled "FUNCTIONAL ICON PLACEHOLDERS — swap real 
icons here" — the assets are reference PNGs via expiring CDN URLs. The 
correct production approach is inline SVG paths that:
- Inherit `currentColor` (so colour is set by CSS, no extra props needed)
- Scale perfectly at any size
- Have no external dependencies
- Are accessible with `aria-hidden` / `aria-label`

---

## SECTION 1 — Install Icon component

Copy `Icon.tsx` into `components/ui/ds/`.

Add to `components/ui/ds/index.ts`:

```ts
export { Icon } from './Icon';
export type { IconProps, IconName } from './Icon';
```

---

## SECTION 2 — How to use

```tsx
import { Icon } from '@/components/ui/ds';

// Basic — inherits colour from parent CSS
<Icon name="plus" size={16} />

// With explicit colour
<Icon name="close" size={14} color="#6b1e2e" />

// With accessibility label (for icon-only buttons)
<Icon name="trash" size={16} aria-label="Delete review" />

// Inside a button — colour comes from button's CSS
<button className={styles.btn}>
  <Icon name="edit" size={14} />
  Edit
</button>
```

Icon names follow the DLS naming convention:
- Nav: `nav-home`, `nav-reviews`, `nav-decisions`, `nav-drafts`, `nav-archive`, `nav-settings`, `nav-mark`
- Action: `plus`, `minus`, `edit`, `trash`, `share`, `export`, `close`, `check`, `send`, `notification`, `stretch`, `drill-down`, `close-drawer`, `open-drawer`, `kebab`, `filter`, `upload`, `contributor`
- Status: `status-draft`, `status-in-review`, `status-approved`, `status-blocked`, `status-comment`, `status-decision`, `ai-stars`
- Content: `attach`, `link`, `tradeoff`, `chevron-down`, `chevron-up`, `chevron-right`, `chevron-left`, `search`, `info`, `dot`

---

## SECTION 3 — Delete all local SVG/icon implementations

Search for any local icon implementations:

```bash
grep -r "imgVector\|imgUnion\|figma.com/api/mcp/asset" --include="*.tsx" -l
grep -r "<img.*icon\|Icons/" --include="*.tsx" -l
```

For each file found, replace the Figma CDN `<img>` tag with the DS Icon:

**Pattern — Figma img tag:**
```tsx
// BEFORE (expires in 7 days)
<img alt="" className="absolute block inset-0 max-w-none size-full" src={imgVector} />

// AFTER
<Icon name="plus" size={16} />
```

---

## SECTION 4 — Replace icons in DS components

### Sidebar.tsx
```tsx
// Brand mark
<Icon name="nav-mark" size={24} />

// Nav items
<Icon name="nav-archive" size={20} />   // Projects
<Icon name="nav-reviews" size={20} />   // All Reviews
<Icon name="chevron-up" size={20} />    // accordion open
<Icon name="chevron-down" size={20} />  // accordion closed
<Icon name="chevron-right" size={20} /> // All Reviews chevron
```

### PageHeader.tsx
```tsx
<Icon name="search" size={16} />
<Icon name="kebab" size={14} />
<Icon name="nav-settings" size={14} />
<Icon name="share" size={14} />
<Icon name="chevron-down" size={14} />  // ButtonGroup trigger
```

### ButtonGroup.tsx
```tsx
// Replace chevron-down image with:
<Icon name="chevron-down" size={14} />  // sm
<Icon name="chevron-down" size={16} />  // md
<Icon name="chevron-down" size={20} />  // lg
```

### Modal.tsx
```tsx
// Close button
<Icon name="close" size={14} />
```

### ShowAccordion.tsx
```tsx
<Icon name="chevron-down" size={14} />  // show more
<Icon name="chevron-up" size={14} />    // show less
<Icon name="chevron-right" size={14} /> // view all
```

### Tooltip.tsx
No icons needed.

### Checkbox.tsx
The check/dash icons are already inline SVG — no change needed.

### ReviewCard.tsx
No icons needed (tags, status pills handle their own display).

### DecisionCard.tsx
```tsx
// Kebab menu button
<Icon name="kebab" size={14} />
// AI stars (replace the placeholder SVG)
<Icon name="ai-stars" size={20} />
```

### TradeOffBlock.tsx
```tsx
// Info icon in note row
<Icon name="info" size={16} />
// Plus icon in option rows
<Icon name="plus" size={16} />
// Kebab icon
<Icon name="kebab" size={14} />
```

### CommentThread.tsx
```tsx
// Blocked/warning icon
<Icon name="status-blocked" size={16} />
// Drill-down reply icon
<Icon name="drill-down" size={20} />
```

### ArtifactPreview.tsx
```tsx
// Zoom in
<Icon name="plus" size={14} />
// Minimise — the horizontal bar is already CSS, keep as-is
```

---

## SECTION 5 — Replace icons in product pages

Search the entire `app/` directory for icon usages:

```bash
grep -r "imgVector\|figma.com/api/mcp/asset" app/ --include="*.tsx" -l
```

For each page/component found, import Icon and replace `<img>` tags.

Common page-level replacements:
- Filter button: `<Icon name="filter" size={14} />`
- New Project button: `<Icon name="plus" size={14} />`
- Add contributor: `<Icon name="contributor" size={16} />`
- Source file link: `<Icon name="link" size={14} />`
- Upload artifact: `<Icon name="upload" size={16} />`
- Delete/trash actions: `<Icon name="trash" size={14} />`
- Edit actions: `<Icon name="edit" size={14} />`

---

## SECTION 6 — Update barrel export in REGISTRY.md

Add Icon to `components/ui/ds/REGISTRY.md`:

```md
| Icon | 166:2613 | 2026-04-16 | VytA96WG9bMQpx5n0yciGH |
```

---

## SECTION 7 — After all changes

1. `npx tsc --noEmit` — fix all type errors
2. Search for any remaining `figma.com/api/mcp/asset` in the codebase:
   ```bash
   grep -r "figma.com/api/mcp/asset" --include="*.tsx" -l
   ```
   There should be zero results.
3. Pause OneDrive sync, `rd /s /q .next`, restart dev server
4. Verify every icon renders correctly in the browser at multiple sizes
