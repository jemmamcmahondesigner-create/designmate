'use client';

import { useState } from 'react';
import { Avatar } from './Avatar';
import { Tooltip } from './Tooltip';
import styles from './CommentThread.module.css';

export type CommentType =
  | 'feedback'
  | 'with-reply'
  | 'no-feedback'
  | 'decision-required'
  | 'decision';

export interface CommentReply {
  authorName: string;
  authorAvatarSrc?: string;
  body: string;
  timestamp?: string;
}

export interface CommentThreadProps {
  type?: CommentType;
  /** Is this a stakeholder (has avatar + name in header) */
  isStakeholder?: boolean;
  authorName?: string;
  authorAvatarSrc?: string;
  timestamp?: string;
  body?: string;
  /** Tag label on the right of header (e.g. "Feedback", "Decision") */
  tag?: string;
  /** Selected option tag(s) shown below body */
  options?: string[];
  /** For with-reply: the nested reply */
  reply?: CommentReply;
  /** Called when Send is clicked — reply input value passed */
  onSend?: (value: string) => void;
  /** For decision-required (stakeholder): primary CTA */
  onMakeDecision?: () => void;
  className?: string;
}

export function CommentThread({
  type = 'feedback',
  isStakeholder = true,
  authorName,
  authorAvatarSrc,
  timestamp,
  body,
  tag,
  options = [],
  reply,
  onSend,
  onMakeDecision,
  className,
}: CommentThreadProps) {
  const [replyValue, setReplyValue] = useState('');

  const rootClass = [
    styles.root,
    styles[`type-${type}`],
    className ?? '',
  ]
    .filter(Boolean)
    .join(' ');

  const isEmpty = type === 'no-feedback' || type === 'decision-required';
  const showBody = !isEmpty && body;
  const showReplyInput = (type === 'feedback' || type === 'with-reply' || type === 'decision') && isStakeholder;
  const showMakeCta = type === 'decision-required' && isStakeholder;

  const handleSend = () => {
    if (replyValue.trim()) {
      onSend?.(replyValue);
      setReplyValue('');
    }
  };

  return (
    <div className={rootClass}>
      {/* Header row */}
      <div className={styles.header}>
        {/* Avatar */}
        {isStakeholder && (
          <Avatar src={authorAvatarSrc} name={authorName} size="md" />
        )}

        {/* Name + timestamp */}
        {isEmpty ? (
          /* Empty states: name fills, then status + icon right-aligned */
          <>
            <span className={styles.authorFill}>{authorName}</span>
            <span className={styles.statusText}>
              {type === 'decision-required' ? 'Decision Required' : 'Feedback required'}
            </span>
            <Tooltip
              label={
                type === 'decision-required'
                  ? 'Waiting for this stakeholder to provide a final decision'
                  : 'Waiting for feedback. Send a reminder or share a link to the review.'
              }
              position="top"
            >
              <span className={styles.blockedIcon} aria-label="Pending">
                <BlockedIcon />
              </span>
            </Tooltip>
          </>
        ) : (
          <>
            {type === 'with-reply' ? (
              /* with-reply: avatar + name grouped */
              <div className={styles.authorGroup}>
                {type === 'with-reply' && isStakeholder && (
                  <Avatar src={authorAvatarSrc} name={authorName} size="md" />
                )}
                <span className={styles.authorName}>{authorName}</span>
              </div>
            ) : (
              <span className={styles.authorName}>{authorName}</span>
            )}
            {timestamp && <span className={styles.dot}>·</span>}
            {timestamp && <span className={styles.timestamp}>{timestamp}</span>}
            {/* Tag right-aligned */}
            {tag && <span className={[styles.tag, type === 'decision' ? styles.tagDecision : ''].join(' ')}>{tag}</span>}
          </>
        )}

        {/* Feedback tag for plain feedback type */}
        {!isEmpty && type === 'feedback' && tag && !tag && (
          <span className={styles.tag}>{tag}</span>
        )}
      </div>

      {/* Body */}
      {showBody && (
        <p className={styles.body}>{body}</p>
      )}

      {/* Option tags */}
      {options.length > 0 && (
        <div className={styles.options}>
          {options.map((opt, i) => (
            <span key={i} className={[styles.optionTag, type === 'decision' ? styles.optionTagDecision : ''].join(' ')}>
              {opt}
            </span>
          ))}
        </div>
      )}

      {/* Reply bubble (with-reply type) */}
      {type === 'with-reply' && reply && (
        <div className={styles.replyBubble}>
          <DrillDownIcon />
          <div className={styles.replyContent}>
            <p className={styles.replyBody}>{reply.body}</p>
            <div className={styles.replyMeta}>
              {reply.authorAvatarSrc || reply.authorName ? (
                <Avatar src={reply.authorAvatarSrc} name={reply.authorName} size="md" />
              ) : null}
              {reply.authorName && <span className={styles.replyAuthor}>{reply.authorName}</span>}
              {reply.timestamp && <span className={styles.dot}>·</span>}
              {reply.timestamp && <span className={styles.timestamp}>{reply.timestamp}</span>}
            </div>
          </div>
        </div>
      )}

      {/* Reply input */}
      {showReplyInput && (
        <div className={styles.replyRow}>
          <input
            type="text"
            className={styles.replyInput}
            placeholder="Reply..."
            value={replyValue}
            onChange={e => setReplyValue(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && handleSend()}
            aria-label="Reply"
          />
          <button
            type="button"
            className={styles.sendBtn}
            onClick={handleSend}
          >
            Send
          </button>
        </div>
      )}

      {/* Make Decision CTA */}
      {showMakeCta && (
        <button type="button" className={styles.makeDecisionBtn} onClick={onMakeDecision}>
          Make Decision
        </button>
      )}
    </div>
  );
}

/* ── Inline SVG icons ───────────────────────────────────────────────────────── */

function BlockedIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
      <circle cx="8" cy="8" r="6" stroke="#e5b025" strokeWidth="1.4" />
      <path d="M8 5v4M8 11v.5" stroke="#e5b025" strokeWidth="1.4" strokeLinecap="round" />
    </svg>
  );
}

function DrillDownIcon() {
  return (
    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" style={{ flexShrink: 0, marginTop: 2 }}>
      <path d="M6 4v8M6 12l4 4M6 12l-4 4" stroke="#998c82" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}
