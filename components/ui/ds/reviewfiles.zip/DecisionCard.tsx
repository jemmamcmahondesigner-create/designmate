'use client';

import { Avatar } from './Avatar';
import { Icon } from './index';
import styles from './DecisionCard.module.css';

export type DecisionStatus = 'approved' | 'changes-needed' | 'rejected' | 'closed';

export interface DecisionOption {
  label: string;
}

export interface DecisionCardProps {
  status: DecisionStatus;
  size?: 'large' | 'small';
  decisionText: string;
  ownerName?: string;
  ownerAvatarSrc?: string;
  dateLabel?: string;
  options?: DecisionOption[];
  /** Whether to show the trade-off accepted block */
  hasTradeOff?: boolean;
  tradeOffNote?: string;
  onMenuClick?: () => void;
  className?: string;
}

const STATUS_CONFIG: Record<DecisionStatus, { label: string; bgClass: string; pillClass: string; textClass: string }> = {
  approved:       { label: 'Approved',        bgClass: styles.headerBase,    pillClass: styles.pillApproved,  textClass: styles.headerTextBase },
  'changes-needed': { label: 'Changes Needed', bgClass: styles.headerWarning, pillClass: styles.pillChanges,  textClass: styles.headerTextBase },
  rejected:       { label: 'Rejected',         bgClass: styles.headerError,   pillClass: styles.pillRejected, textClass: styles.headerTextBase },
  closed:         { label: 'Closed',           bgClass: styles.headerBase,    pillClass: styles.pillClosed,   textClass: styles.headerTextBase },
};

export function DecisionCard({
  status,
  size = 'large',
  decisionText,
  ownerName,
  ownerAvatarSrc,
  dateLabel,
  options = [],
  hasTradeOff = false,
  tradeOffNote,
  onMenuClick,
  className,
}: DecisionCardProps) {
  const cfg = STATUS_CONFIG[status];

  const rootClass = [
    styles.root,
    size === 'small' ? styles.small : '',
    className ?? '',
  ]
    .filter(Boolean)
    .join(' ');

  return (
    <article className={rootClass}>
      {/* Header band */}
      <div className={[styles.header, cfg.bgClass].join(' ')}>
        <span className={styles.headerLabel}>Decision Status</span>
        <span className={[styles.pill, cfg.pillClass].join(' ')}>
          {cfg.label}
        </span>
      </div>

      {/* Body */}
      <div className={styles.body}>
        {/* Option tags */}
        {options.length > 0 && (
          <div className={styles.options}>
            {options.map((opt, i) => (
              <span key={i} className={styles.optionTag}>{opt.label}</span>
            ))}
          </div>
        )}

        <div className={styles.content}>
          {/* Decision text */}
          <p className={styles.decisionText}>{decisionText}</p>

          {/* Owner + date + kebab */}
          <div className={styles.ownerRow}>
            <div className={styles.ownerDetails}>
              {(ownerName || ownerAvatarSrc) && (
                <Avatar src={ownerAvatarSrc} name={ownerName} size="md" />
              )}
              {ownerName && (
                <span className={styles.ownerName}>{ownerName}</span>
              )}
              {dateLabel && (
                <>
                  <span className={styles.dot}>·</span>
                  <span className={styles.date}>{dateLabel}</span>
                </>
              )}
            </div>
            {onMenuClick && (
              <button
                type="button"
                className={styles.kebabBtn}
                onClick={onMenuClick}
                aria-label="More options"
              >
                <Icon name="kebab" size={14} />
              </button>
            )}
          </div>
        </div>

        {/* Trade-off block */}
        {size === 'large' && hasTradeOff && (
          <div className={styles.tradeOff}>
            <div className={styles.tradeOffHeader}>
              <span className={styles.tradeOffLabel}>TRADE-OFF ACCEPTED</span>
              <AiStarsIcon />
            </div>
            {tradeOffNote && (
              <p className={styles.tradeOffNote}>{tradeOffNote}</p>
            )}
          </div>
        )}
      </div>
    </article>
  );
}

/* ── AI Stars icon — inline SVG, no expiring CDN URL ────────────────────────── */
function AiStarsIcon() {
  return (
    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
      <path d="M10 2L11.5 7H16.5L12.5 10.5L14 15.5L10 12.5L6 15.5L7.5 10.5L3.5 7H8.5L10 2Z" fill="#998c82" fillOpacity="0.6"/>
      <path d="M16 1L16.8 3.2L19 4L16.8 4.8L16 7L15.2 4.8L13 4L15.2 3.2L16 1Z" fill="#998c82" fillOpacity="0.5"/>
    </svg>
  );
}
