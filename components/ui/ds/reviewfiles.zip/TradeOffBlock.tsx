'use client';

import styles from './TradeOffBlock.module.css';

export type TradeOffSentiment = 'success' | 'brand' | 'error';

export interface TradeOffOption {
  sentiment: TradeOffSentiment;
  heading?: string;
  body: string;
  /** Short label e.g. "Good", "High" */
  pillLabel?: string;
  showKebab?: boolean;
  onKebabClick?: () => void;
  /** Primary action button label (brand/dark rows) */
  actionLabel?: string;
  onActionClick?: () => void;
}

export interface TradeOffBlockProps {
  /** Contextual note about why this trade-off exists */
  note?: string;
  options: TradeOffOption[];
  className?: string;
}

export function TradeOffBlock({ note, options, className }: TradeOffBlockProps) {
  const rootClass = [styles.root, className ?? ''].filter(Boolean).join(' ');

  return (
    <div className={rootClass}>
      {/* Header */}
      <div className={styles.header}>
        <span className={styles.headerLabel}>TRADE-OFF</span>
      </div>

      {/* Note */}
      {note && (
        <div className={styles.noteRow}>
          <InfoIcon />
          <span className={styles.noteText}>{note}</span>
        </div>
      )}

      {/* Option rows */}
      <div className={styles.options}>
        {options.map((opt, i) => (
          <OptionRow key={i} option={opt} />
        ))}
      </div>
    </div>
  );
}

/* ── Option row ─────────────────────────────────────────────────────────────── */

function OptionRow({ option }: { option: TradeOffOption }) {
  const { sentiment, heading, body, pillLabel, showKebab, onKebabClick, actionLabel, onActionClick } = option;

  const rowClass = [
    styles.row,
    styles[`row-${sentiment}`],
  ].join(' ');

  const isBrand = sentiment === 'brand';

  return (
    <div className={rowClass}>
      {/* Left: heading + body */}
      <div className={styles.rowLeft}>
        {heading && (
          <div className={styles.rowHeading}>
            <PlusIcon sentiment={sentiment} />
            <span className={[styles.rowHeadingText, isBrand ? styles.rowHeadingInverse : ''].join(' ')}>
              {heading}
            </span>
          </div>
        )}
        <div className={styles.rowContent}>
          <p className={[styles.rowBody, isBrand ? styles.rowBodyInverse : ''].join(' ')}>
            {body}
          </p>
          <div className={styles.rowActions}>
            {pillLabel && (
              <span className={[styles.pill, styles[`pill-${sentiment}`]].join(' ')}>
                {pillLabel}
              </span>
            )}
            {showKebab && onKebabClick && (
              <button type="button" className={[styles.iconBtn, isBrand ? styles.iconBtnInverse : ''].join(' ')} onClick={onKebabClick} aria-label="More options">
                <KebabIcon inverse={isBrand} />
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Right: action button (brand rows) */}
      {actionLabel && (
        <div className={styles.rowRight}>
          <button type="button" className={styles.actionBtn} onClick={onActionClick}>
            {actionLabel}
          </button>
        </div>
      )}
    </div>
  );
}

/* ── Inline SVG icons ───────────────────────────────────────────────────────── */

function InfoIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" style={{ flexShrink: 0 }}>
      <circle cx="8" cy="8" r="6.5" stroke="#998c82" strokeWidth="1.3" />
      <rect x="7.3" y="7" width="1.4" height="5" rx="0.7" fill="#998c82" />
      <circle cx="8" cy="5" r="0.8" fill="#998c82" />
    </svg>
  );
}

function PlusIcon({ sentiment }: { sentiment: TradeOffSentiment }) {
  const color = sentiment === 'brand' ? '#ffffff' : '#6b1e2e';
  return (
    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
      <path d="M8 3v10M3 8h10" stroke={color} strokeWidth="1.5" strokeLinecap="round" />
    </svg>
  );
}

function KebabIcon({ inverse }: { inverse?: boolean }) {
  const color = inverse ? '#ffffff' : '#6b5e55';
  return (
    <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
      <circle cx="7" cy="3" r="1.2" fill={color} />
      <circle cx="7" cy="7" r="1.2" fill={color} />
      <circle cx="7" cy="11" r="1.2" fill={color} />
    </svg>
  );
}
