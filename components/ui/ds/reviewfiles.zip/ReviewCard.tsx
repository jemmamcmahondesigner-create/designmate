'use client';

import { Avatar } from './Avatar';
import { Tag } from './Tag';
import { StatusPill } from './StatusPill';
import styles from './ReviewCard.module.css';

export type ReviewStatus = 'draft' | 'in-review' | 'approved' | 'needs-changes' | 'blocked';

export interface ReviewCardTag {
  label: string;
  variant?: 'default' | 'aqua' | 'brand' | 'mint' | 'butter' | 'warning' | 'success' | 'error' | 'neutral';
}

export interface ReviewCardProps {
  title: string;
  status: ReviewStatus;
  /** Name of the review owner */
  ownerName?: string;
  ownerAvatarSrc?: string;
  dateLabel?: string;
  description?: string;
  /** Show the description body */
  showDescription?: boolean;
  /** Show the artifact attachment row */
  hasArtifact?: boolean;
  artifactLabel?: string;
  tags?: ReviewCardTag[];
  commentCount?: number;
  decisionCount?: number;
  onClick?: () => void;
  className?: string;
}

const STATUS_LABELS: Record<ReviewStatus, string> = {
  draft: 'Draft',
  'in-review': 'In Review',
  approved: 'Approved',
  'needs-changes': 'Needs Changes',
  blocked: 'Blocked',
};

export function ReviewCard({
  title,
  status,
  ownerName,
  ownerAvatarSrc,
  dateLabel,
  description,
  showDescription = true,
  hasArtifact = false,
  artifactLabel,
  tags = [],
  commentCount,
  decisionCount,
  onClick,
  className,
}: ReviewCardProps) {
  const isNeedsChanges = status === 'needs-changes';

  const rootClass = [
    styles.root,
    styles[`status-${status}`],
    className ?? '',
  ]
    .filter(Boolean)
    .join(' ');

  const titleClass = [
    styles.title,
    isNeedsChanges ? styles.titleWarning : '',
  ]
    .filter(Boolean)
    .join(' ');

  const dividerClass = [
    styles.divider,
    isNeedsChanges ? styles.dividerStrong : '',
  ]
    .filter(Boolean)
    .join(' ');

  const countsClass = [
    styles.counts,
    isNeedsChanges ? styles.countsWarning : '',
  ]
    .filter(Boolean)
    .join(' ');

  const artifactClass = [
    styles.artifact,
    isNeedsChanges ? styles.artifactLight : '',
  ]
    .filter(Boolean)
    .join(' ');

  return (
    <article
      className={rootClass}
      onClick={onClick}
      role={onClick ? 'button' : undefined}
      tabIndex={onClick ? 0 : undefined}
      onKeyDown={onClick ? (e) => e.key === 'Enter' && onClick() : undefined}
    >
      {/* Title */}
      <h3 className={titleClass}>{title}</h3>

      {/* Status row */}
      <div className={styles.meta}>
        <StatusPill status={status} label={STATUS_LABELS[status]} size="sm" />
        {(ownerName || ownerAvatarSrc) && (
          <Avatar src={ownerAvatarSrc} name={ownerName} size="md" />
        )}
        {dateLabel && (
          <span className={styles.date}>{dateLabel}</span>
        )}
      </div>

      {/* Description */}
      {showDescription && description && (
        <p className={styles.description}>{description}</p>
      )}

      {/* Artifact */}
      {hasArtifact && (
        <div className={artifactClass}>
          <span className={styles.artifactText}>
            📎&nbsp;&nbsp;{artifactLabel ?? 'Figma artifact attached'}
          </span>
        </div>
      )}

      {/* Tags */}
      {tags.length > 0 && (
        <div className={styles.tags}>
          {tags.map((tag, i) => (
            <Tag key={i} label={tag.label} variant={tag.variant ?? 'default'} size="sm" />
          ))}
        </div>
      )}

      {/* Footer counts */}
      {(commentCount !== undefined || decisionCount !== undefined) && (
        <>
          <span className={dividerClass} />
          <div className={countsClass}>
            {commentCount !== undefined && (
              <span>{commentCount} {commentCount === 1 ? 'comment' : 'comments'}</span>
            )}
            {decisionCount !== undefined && (
              <span>{decisionCount} {decisionCount === 1 ? 'decision' : 'decisions'}</span>
            )}
          </div>
        </>
      )}
    </article>
  );
}
