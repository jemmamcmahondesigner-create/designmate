'use client';

import {
  useEffect,
  useRef,
  type ReactNode,
  type KeyboardEvent,
} from 'react';
import { Icon, type IconName } from './Icon';
import { Avatar } from './Avatar';
import { Checkbox } from './Checkbox';
import { Button } from './Button';
import styles from './Menu.module.css';

// ─── Types ────────────────────────────────────────────────────────────────────

export type MenuType = 'dropdown' | 'context-menu' | 'action-menu' | 'multi-select';
export type MenuItemVariant = 'icon' | 'avatar';
export type MenuFooterType = 'link' | 'delete' | 'button';

// ─── MenuFooter ───────────────────────────────────────────────────────────────
// DLS node 265:4560
//
// type="link"   — [+ icon] [brand-colour label] — create/add action
// type="delete" — [trash icon] [red label] — destructive action
// type="button" — [primary "Done" button] [optional + Link action right]
//                 Used in Problems section, Contributors section
//                 showAdditionalLink controls the "+ Link" on the right

export interface MenuFooterProps {
  type: MenuFooterType;
  /** Label for the action (defaults: Link → "Link", Delete → "Delete", Button → "Done") */
  label?: string;
  /** type="button" only — shows a "+ Link" text action on the right */
  additionalLinkLabel?: string;
  onAdditionalLink?: () => void;
  /** Whether to show the additional link (type="button" only, default true) */
  showAdditionalLink?: boolean;
  onClick?: () => void;
}

export function MenuFooter({
  type,
  label,
  additionalLinkLabel,
  onAdditionalLink,
  showAdditionalLink = true,
  onClick,
}: MenuFooterProps) {
  const isDelete = type === 'delete';
  const isButton = type === 'button';
  const isLink = type === 'link';

  const defaultLabel = isDelete ? 'Delete' : isButton ? 'Done' : 'Link';

  if (isButton) {
    return (
      <li role="menuitem" className={styles.footerButton}>
        {/* Primary "Done" button */}
        <Button
          variant="primary"
          size="sm"
          label={label ?? defaultLabel}
          onClick={onClick}
        />
        {/* Optional "+ Link" action on the right */}
        {showAdditionalLink && (
          <button
            type="button"
            className={styles.footerAdditionalLink}
            onClick={onAdditionalLink}
          >
            <Icon name="plus" size={16} color="#6b1e2e" />
            <span>{additionalLinkLabel ?? 'Link'}</span>
          </button>
        )}
      </li>
    );
  }

  return (
    <li
      role="menuitem"
      tabIndex={0}
      className={[
        styles.footer,
        isDelete ? styles.footerDelete : styles.footerLink,
      ].join(' ')}
      onClick={onClick}
      onKeyDown={(e: KeyboardEvent) => {
        if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); onClick?.(); }
      }}
    >
      <span className={styles.footerIcon} aria-hidden="true">
        <Icon name={isDelete ? 'trash' : 'plus'} size={16} />
      </span>
      <span className={styles.footerLabel}>{label ?? defaultLabel}</span>
    </li>
  );
}

// ─── MenuItem ─────────────────────────────────────────────────────────────────
// DLS node 120:3899

export interface MenuItemProps {
  label: string;
  icon?: IconName;
  avatarSrc?: string;
  avatarName?: string;
  /** Checkbox mode — for multi-select menus */
  checkbox?: boolean;
  active?: boolean;
  disabled?: boolean;
  dividerAbove?: boolean;
  onClick?: () => void;
}

export function MenuItem({
  label,
  icon,
  avatarSrc,
  avatarName,
  checkbox = false,
  active = false,
  disabled = false,
  dividerAbove = false,
  onClick,
}: MenuItemProps) {
  const hasAvatar = !!(avatarSrc || avatarName);
  const iconColor = active ? '#6b1e2e' : '#6b5e55';

  return (
    <>
      {dividerAbove && <div className={styles.divider} role="separator" />}
      <li
        role={checkbox ? 'menuitemcheckbox' : 'menuitem'}
        aria-checked={checkbox ? active : undefined}
        aria-selected={!checkbox ? active : undefined}
        aria-disabled={disabled}
        tabIndex={disabled ? -1 : 0}
        className={[
          styles.item,
          active ? styles.itemActive : '',
          disabled ? styles.itemDisabled : '',
        ].filter(Boolean).join(' ')}
        onClick={() => !disabled && onClick?.()}
        onKeyDown={(e: KeyboardEvent) => {
          if ((e.key === 'Enter' || e.key === ' ') && !disabled) {
            e.preventDefault();
            onClick?.();
          }
        }}
      >
        {checkbox && (
          <span className={styles.itemCheckbox} aria-hidden="true">
            <Checkbox checked={active} onChange={() => {}} />
          </span>
        )}

        {hasAvatar ? (
          <span className={styles.itemAvatar}>
            <Avatar src={avatarSrc} name={avatarName} size="md" />
          </span>
        ) : icon ? (
          <span className={styles.itemIcon} aria-hidden="true">
            <Icon name={icon} size={16} color={iconColor} />
          </span>
        ) : null}

        <span className={[
          styles.itemLabel,
          active && !checkbox ? styles.itemLabelActive : '',
        ].filter(Boolean).join(' ')}>
          {label}
        </span>

        {active && !checkbox && (
          <span className={styles.itemCheck} aria-hidden="true">
            <Icon name="check" size={16} color="#6b1e2e" />
          </span>
        )}
      </li>
    </>
  );
}

// ─── Menu ─────────────────────────────────────────────────────────────────────
// DLS node 112:163

export interface MenuProps {
  open: boolean;
  onClose: () => void;
  children: ReactNode;
  type?: MenuType;
  /** Footer action — renders below a divider */
  footerAction?: MenuFooterProps;
  anchorRef?: React.RefObject<HTMLElement>;
  align?: 'left' | 'right';
  'aria-label'?: string;
  className?: string;
}

export function Menu({
  open,
  onClose,
  children,
  type = 'dropdown',
  footerAction,
  anchorRef,
  align = 'left',
  'aria-label': ariaLabel = 'Menu',
  className,
}: MenuProps) {
  const menuRef = useRef<HTMLUListElement>(null);

  useEffect(() => {
    if (!open) return;
    const handler = (e: MouseEvent) => {
      if (menuRef.current?.contains(e.target as Node)) return;
      if (anchorRef?.current?.contains(e.target as Node)) return;
      onClose();
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, [open, onClose, anchorRef]);

  useEffect(() => {
    if (!open) return;
    const handler = (e: globalThis.KeyboardEvent) => {
      if (e.key === 'Escape') { onClose(); return; }
      if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
        e.preventDefault();
        const items = Array.from(
          menuRef.current?.querySelectorAll<HTMLElement>(
            '[role="menuitem"],[role="menuitemcheckbox"]:not([aria-disabled="true"])'
          ) ?? []
        );
        const idx = items.indexOf(document.activeElement as HTMLElement);
        const next = e.key === 'ArrowDown'
          ? items[Math.min(idx + 1, items.length - 1)]
          : items[Math.max(idx - 1, 0)];
        next?.focus();
      }
    };
    document.addEventListener('keydown', handler);
    return () => document.removeEventListener('keydown', handler);
  }, [open, onClose]);

  useEffect(() => {
    if (!open) return;
    const t = setTimeout(() => {
      const first = menuRef.current?.querySelector<HTMLElement>(
        '[role="menuitem"],[role="menuitemcheckbox"]:not([aria-disabled="true"])'
      );
      first?.focus();
    }, 10);
    return () => clearTimeout(t);
  }, [open]);

  if (!open) return null;

  const hasFooter = !!footerAction;

  return (
    <ul
      ref={menuRef}
      role="menu"
      aria-label={ariaLabel}
      className={[
        styles.menu,
        align === 'right' ? styles.alignRight : styles.alignLeft,
        hasFooter ? styles.overflow : '',
        className ?? '',
      ].filter(Boolean).join(' ')}
    >
      {hasFooter ? (
        <div className={styles.itemsGroup}>{children}</div>
      ) : children}

      {footerAction && (
        <>
          <div className={styles.divider} role="separator" />
          <MenuFooter {...footerAction} />
        </>
      )}
    </ul>
  );
}
