# MenuFooter Update — Button Type for Problems & Contributors

The DLS `MenuFooter` has a new `type="button"` variant.
Replace `components/ui/ds/Menu.tsx` and `Menu.module.css` with the new files.

Run `npx tsc --noEmit` after each section.

---

## What changed

`MenuFooter` now has three types:

| Type | Layout | Use case |
|------|--------|----------|
| `link` | `[+ icon] [brand label]` | Create new item (existing) |
| `delete` | `[trash icon] [red label]` | Destructive action (existing) |
| `button` | `[primary Done btn] [optional + Link]` | **NEW** — confirm multi-select |

The `button` type is specifically for multi-select menus where the user:
1. Checks items from the list
2. Presses **Done** to confirm the selection
3. Optionally presses **+ Create new** to add a new item

```tsx
// New MenuFooterProps additions:
additionalLinkLabel?: string;   // label for the right-side link (default "Link")
onAdditionalLink?: () => void;  // click handler for the right-side link
showAdditionalLink?: boolean;   // whether to show it (default true)
```

---

## SECTION 1 — Update ProblemsSection

Find `ProblemsSection.tsx` (or the component where problems are added/selected
from a dropdown). The combobox that opens when a user clicks "+ Add problem"
should use the `button` footer type.

The pattern: user types to search existing problems, checks one or more,
then presses "Done" to apply. "+ Create problem" link creates a new one.

```tsx
import { Menu, MenuItem, MenuFooter } from '@/components/ui/ds';

const [problemMenuOpen, setProblemMenuOpen] = useState(false);
const [selectedProblemIds, setSelectedProblemIds] = useState<string[]>([]);

const toggleProblem = (id: string) =>
  setSelectedProblemIds(prev =>
    prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]
  );

const handleDone = () => {
  setProblemMenuOpen(false);
  // selectedProblemIds are now confirmed — save to DB or parent state
  onProblemsChange?.(selectedProblemIds);
};

// Wrapper must be position: relative
<div style={{ position: 'relative' }}>
  <button
    type="button"
    className={styles.addBtn}
    onClick={() => setProblemMenuOpen(o => !o)}
  >
    <Icon name="plus" size={14} />
    Add problem
  </button>

  <Menu
    open={problemMenuOpen}
    onClose={() => setProblemMenuOpen(false)}
    type="multi-select"
    align="left"
    aria-label="Select problems"
    footerAction={{
      type: 'button',
      label: 'Done',
      onClick: handleDone,
      additionalLinkLabel: 'Create problem',
      onAdditionalLink: () => {
        setProblemMenuOpen(false);
        openCreateProblemFlow();  // open inline form or modal
      },
      showAdditionalLink: true,
    }}
  >
    {problems.map(p => (
      <MenuItem
        key={p.id}
        label={p.description}
        checkbox
        active={selectedProblemIds.includes(p.id)}
        onClick={() => toggleProblem(p.id)}
      />
    ))}
  </Menu>
</div>
```

---

## SECTION 2 — Update ContributorsSection / ReviewersSection

Same pattern for the contributor/reviewer combobox. Users check avatars
from the list, press Done, or create a new contributor.

```tsx
<Menu
  open={contributorMenuOpen}
  onClose={() => setContributorMenuOpen(false)}
  type="multi-select"
  align="left"
  aria-label="Select contributors"
  footerAction={{
    type: 'button',
    label: 'Done',
    onClick: () => {
      setContributorMenuOpen(false);
      onContributorsChange?.(selectedContributorIds);
    },
    additionalLinkLabel: 'Create contributor',
    onAdditionalLink: () => {
      setContributorMenuOpen(false);
      openCreateContributorFlow();
    },
    showAdditionalLink: true,
  }}
>
  {contributors.map(c => (
    <MenuItem
      key={c.id}
      label={c.name}
      avatarSrc={c.avatar_url ?? undefined}
      avatarName={c.name}
      checkbox
      active={selectedContributorIds.includes(c.id)}
      onClick={() => toggleContributor(c.id)}
    />
  ))}
</Menu>
```

---

## SECTION 3 — TypeScript export update

In `components/ui/ds/index.ts` ensure `MenuFooterType` includes `'button'`:

```ts
export type { MenuProps, MenuItemProps, MenuFooterProps, MenuType, MenuFooterType } from './Menu';
```

The `MenuFooterType` union in `Menu.tsx` is now `'link' | 'delete' | 'button'`.
If anything in the product passes `type="Link"` or `type="Delete"` (PascalCase),
rename to `'link'` / `'delete'` (kebab-case).

---

## SECTION 4 — After changes

1. `npx tsc --noEmit` — must pass clean
2. Pause OneDrive, `rd /s /q .next`, restart dev
3. Check:
   - "+ Add problem" → opens menu with checkboxes → "Done" button + "Create problem" link in footer
   - "+ Add contributor" → same pattern with avatars
   - "Done" closes menu and applies selection
   - "Create problem/contributor" closes menu and opens creation flow
   - Existing link/delete footers (kebab menus) unchanged
