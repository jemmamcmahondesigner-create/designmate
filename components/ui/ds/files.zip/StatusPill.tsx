'use client';

import { Icon } from './index';
import styles from './StatusPill.module.css';

export type StatusPillStatus =
  | 'draft'
  | 'in-review'
  | 'approved'
  | 'needs-changes'
  | 'blocked'
  | 'closed';

export type StatusPillSize = 'sm' | 'md' | 'lg';
export type StatusPillProminence = 'default' | 'high';
export type StatusPillState = 'default' | 'interactive';

export interface StatusPillProps {
  label: string;
  status?: StatusPillStatus;
  size?: StatusPillSize;
  prominence?: StatusPillProminence;
  state?: StatusPillState;
  /** Called when interactive lg pill is clicked */
  onClick?: () => void;
  className?: string;
}

export function StatusPill({
  label,
  status = 'draft',
  size = 'sm',
  prominence = 'default',
  state = 'default',
  onClick,
  className,
}: StatusPillProps) {
  const isInteractive = state === 'interactive' && size === 'lg';

  const rootClass = [
    styles.root,
    styles[`status-${status}`],
    styles[`size-${size}`],
    prominence === 'high' ? styles.high : '',
    isInteractive ? styles.interactive : '',
    className ?? '',
  ]
    .filter(Boolean)
    .join(' ');

  const Tag = isInteractive ? 'button' : 'span';

  return (
    <Tag
      className={rootClass}
      onClick={isInteractive ? onClick : undefined}
      type={isInteractive ? 'button' : undefined}
      aria-haspopup={isInteractive ? 'menu' : undefined}
    >
      <span className={styles.label}>{label}</span>
      {isInteractive && (
        <span className={styles.chevron} aria-hidden="true">
          <Icon name="chevron-down" size={14} />
        </span>
      )}
    </Tag>
  );
}
