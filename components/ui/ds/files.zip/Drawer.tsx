'use client';

import { useEffect, useRef } from 'react';
import { Icon } from './index';
import styles from './Drawer.module.css';

export type DrawerType = 'detail' | 'edit' | 'create' | 'filter';
export type DrawerWidth = 360 | 480 | 600;

export interface DrawerProps {
  open: boolean;
  type?: DrawerType;
  width?: DrawerWidth;
  title?: string;
  subtitle?: string;
  onClose: () => void;
  /** Body content — form fields, detail sections, etc. */
  children?: React.ReactNode;
  /** Footer actions — rendered automatically for edit/create/filter types.
   *  Pass null to suppress the default footer and render your own via children. */
  footer?: React.ReactNode;
  className?: string;
}

const DEFAULT_TITLES: Record<DrawerType, string> = {
  detail: 'Review details',
  edit: 'Edit review',
  create: 'New review',
  filter: 'Filter reviews',
};

const DEFAULT_SUBTITLES: Record<DrawerType, string> = {
  detail: 'Optional subtitle or supporting context',
  edit: 'Update review fields and context',
  create: 'Define problem, attach artifact',
  filter: 'Apply filters to the review list',
};

export function Drawer({
  open,
  type = 'detail',
  width = 360,
  title,
  subtitle,
  onClose,
  children,
  footer,
  className,
}: DrawerProps) {
  const drawerRef = useRef<HTMLDivElement>(null);

  // Escape key closes drawer
  useEffect(() => {
    if (!open) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [open, onClose]);

  // Focus trap: focus first focusable element on open
  useEffect(() => {
    if (!open || !drawerRef.current) return;
    const focusable = drawerRef.current.querySelectorAll<HTMLElement>(
      'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])'
    );
    focusable[0]?.focus();
  }, [open]);

  if (!open) return null;

  const resolvedTitle = title ?? DEFAULT_TITLES[type];
  const resolvedSubtitle = subtitle ?? DEFAULT_SUBTITLES[type];
  const hasFooter = type !== 'detail';

  const rootClass = [
    styles.root,
    styles[`width-${width}`],
    className ?? '',
  ]
    .filter(Boolean)
    .join(' ');

  return (
    <>
      {/* Scrim — click to close */}
      <div className={styles.scrim} onClick={onClose} aria-hidden="true" />

      <div
        ref={drawerRef}
        className={rootClass}
        role="dialog"
        aria-modal="true"
        aria-label={resolvedTitle}
      >
        {/* Header */}
        <div className={styles.header}>
          <div className={styles.headerText}>
            <p className={styles.title}>{resolvedTitle}</p>
            <p className={styles.subtitle}>{resolvedSubtitle}</p>
          </div>
          <button
            type="button"
            className={styles.closeBtn}
            onClick={onClose}
            aria-label="Close drawer"
          >
            <Icon name="close" size={14} />
          </button>
        </div>

        <div className={styles.divider} />

        {/* Body */}
        <div className={styles.body}>{children}</div>

        {/* Footer */}
        {hasFooter && footer !== null && (
          <>
            {type === 'filter' && <div className={styles.footerDivider} />}
            <div className={styles.footer}>
              <div className={styles.footerSpacer} />
              {footer ?? <DefaultFooter type={type} onClose={onClose} />}
            </div>
          </>
        )}
      </div>
    </>
  );
}

function DefaultFooter({ type, onClose }: { type: DrawerType; onClose: () => void }) {
  if (type === 'filter') {
    return (
      <>
        <button type="button" className={styles.btnSecondary} onClick={onClose}>
          Clear all
        </button>
        <button type="submit" className={styles.btnPrimary}>
          Apply filters
        </button>
      </>
    );
  }
  return (
    <>
      <button type="button" className={styles.btnSecondary} onClick={onClose}>
        Cancel
      </button>
      <button type="submit" className={styles.btnAccent}>
        {type === 'create' ? 'Create' : 'Save'}
      </button>
    </>
  );
}
