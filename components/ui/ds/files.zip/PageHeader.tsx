'use client';

import { StatusPill, StatusPillStatus } from './StatusPill';
import { TabItem } from './TabItem';
import { Icon } from './index';
import styles from './PageHeader.module.css';

export type PageHeaderVariant =
  | 'default'
  | 'detail'
  | 'breadcrumb-tabs'
  | 'breadcrumbs'
  | 'search';

export interface PageHeaderTab {
  label: string;
  badgeCount?: number;
}

export interface PageHeaderProps {
  variant?: PageHeaderVariant;
  pageTitle?: string;
  breadcrumb?: string;
  /** Project/review status shown in the title row */
  status?: StatusPillStatus;
  statusLabel?: string;
  showStatus?: boolean;
  /** Tab bar — used in breadcrumb-tabs variant */
  tabs?: PageHeaderTab[];
  activeTab?: number;
  onTabChange?: (index: number) => void;
  /** Primary CTA label (default: "New Review") */
  primaryAction?: string;
  onPrimaryAction?: () => void;
  onPrimaryActionMenu?: () => void;
  onKebab?: () => void;
  onSearch?: (value: string) => void;
  searchPlaceholder?: string;
  className?: string;
}

export function PageHeader({
  variant = 'default',
  pageTitle = 'Website Redesign',
  breadcrumb = 'Projects  /  Gem Designs & Signs',
  status = 'approved',
  statusLabel = 'Active',
  showStatus = true,
  tabs = [],
  activeTab = 0,
  onTabChange,
  primaryAction = 'New Review',
  onPrimaryAction,
  onPrimaryActionMenu,
  onKebab,
  onSearch,
  searchPlaceholder = 'Filter by project, client, or team member ...',
  className,
}: PageHeaderProps) {
  const isBreadcrumbVariant =
    variant === 'breadcrumb-tabs' || variant === 'breadcrumbs';

  const rootClass = [
    styles.root,
    isBreadcrumbVariant ? styles.tall : styles.slim,
    className ?? '',
  ]
    .filter(Boolean)
    .join(' ');

  return (
    <header className={rootClass}>
      {/* ── Slim variants: default, detail ── */}
      {(variant === 'default' || variant === 'detail') && (
        <div className={styles.slimInner}>
          <div className={styles.titleRow}>
            <h1 className={styles.title}>{pageTitle}</h1>
            {showStatus && variant === 'detail' && (
              <StatusPill
                label={statusLabel}
                status={status}
                size="lg"
                state="interactive"
                onClick={onPrimaryActionMenu}
              />
            )}
          </div>
          <ActionBar
            primaryAction={primaryAction}
            onPrimaryAction={onPrimaryAction}
            onPrimaryActionMenu={onPrimaryActionMenu}
            onKebab={onKebab}
            variant={variant}
          />
        </div>
      )}

      {/* ── Search variant ── */}
      {variant === 'search' && (
        <div className={styles.slimInner}>
          <div className={styles.searchField}>
            <span className={styles.searchIcon} aria-hidden="true">
              <Icon name="search" size={16} />
            </span>
            <input
              className={styles.searchInput}
              type="text"
              placeholder={searchPlaceholder}
              onChange={(e) => onSearch?.(e.target.value)}
              aria-label="Search"
            />
          </div>
          <ActionBar
            primaryAction={primaryAction}
            onPrimaryAction={onPrimaryAction}
            onPrimaryActionMenu={onPrimaryActionMenu}
            onKebab={onKebab}
            variant={variant}
          />
        </div>
      )}

      {/* ── Breadcrumb variants ── */}
      {isBreadcrumbVariant && (
        <>
          <div className={styles.breadcrumbTop}>
            <div className={styles.breadcrumbLeft}>
              <p className={styles.breadcrumb}>{breadcrumb}</p>
              <div className={styles.titleRow}>
                <h1 className={styles.title}>{pageTitle}</h1>
                {showStatus && (
                  <StatusPill
                    label={statusLabel}
                    status={status}
                    size="lg"
                    state="interactive"
                    onClick={onPrimaryActionMenu}
                  />
                )}
              </div>
            </div>
            <ActionBar
              primaryAction={primaryAction}
              onPrimaryAction={onPrimaryAction}
              onPrimaryActionMenu={onPrimaryActionMenu}
              onKebab={onKebab}
              variant={variant}
            />
          </div>
          <div className={styles.breadcrumbDivider} />
        </>
      )}

      {/* ── Tab bar (breadcrumb-tabs only) ── */}
      {variant === 'breadcrumb-tabs' && tabs.length > 0 && (
        <div className={styles.tabBar}>
          <div className={styles.tabs}>
            {tabs.map((tab, i) => (
              <TabItem
                key={tab.label}
                label={tab.label}
                active={i === activeTab}
                style="pill"
                showBadge={!!tab.badgeCount}
                badgeCount={tab.badgeCount}
                onClick={() => onTabChange?.(i)}
              />
            ))}
          </div>
        </div>
      )}
    </header>
  );
}

/* ── Shared action bar ─────────────────────────────────────────────────────── */

interface ActionBarProps {
  primaryAction: string;
  onPrimaryAction?: () => void;
  onPrimaryActionMenu?: () => void;
  onKebab?: () => void;
  variant: PageHeaderVariant;
}

function ActionBar({
  primaryAction,
  onPrimaryAction,
  onPrimaryActionMenu,
  onKebab,
  variant,
}: ActionBarProps) {
  return (
    <div className={styles.actions}>
      {/* Split button group */}
      <div className={styles.buttonGroup}>
        <button
          type="button"
          className={styles.btnGroupPrimary}
          onClick={onPrimaryAction}
        >
          {primaryAction}
        </button>
        <div className={styles.btnGroupDivider} aria-hidden="true" />
        <button
          type="button"
          className={styles.btnGroupArrow}
          onClick={onPrimaryActionMenu}
          aria-label="More actions"
          aria-haspopup="menu"
        >
          <Icon name="chevron-down" size={14} />
        </button>
      </div>

      {/* Kebab / overflow */}
      {(variant === 'detail' || variant === 'breadcrumb-tabs' || variant === 'breadcrumbs') && (
        <button
          type="button"
          className={styles.btnIcon}
          onClick={onKebab}
          aria-label="More options"
        >
          <Icon name="kebab" size={14} />
        </button>
      )}
    </div>
  );
}
