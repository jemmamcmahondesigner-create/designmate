'use client';

import { Icon } from './index';
import styles from './ShowAccordion.module.css';

export type ShowAccordionState = 'more' | 'less' | 'view-all';

export interface ShowAccordionProps {
  state?: ShowAccordionState;
  onClick?: () => void;
  className?: string;
}

const LABELS: Record<ShowAccordionState, string> = {
  more: 'Show more',
  less: 'Show less',
  'view-all': 'View all',
};

export function ShowAccordion({
  state = 'more',
  onClick,
  className,
}: ShowAccordionProps) {
  const rootClass = [styles.root, className ?? ''].filter(Boolean).join(' ');

  const iconName =
    state === 'more'
      ? 'chevron-down'
      : state === 'less'
      ? 'chevron-up'
      : null;

  const trailingIcon = state === 'view-all' ? 'chevron-right' : null;

  return (
    <div className={rootClass}>
      <span className={styles.line} aria-hidden="true" />

      <button
        type="button"
        className={styles.btn}
        onClick={onClick}
        aria-expanded={state === 'more' ? false : state === 'less' ? true : undefined}
      >
        {iconName && (
          <Icon name={iconName} size={14} />
        )}
        <span className={styles.label}>{LABELS[state]}</span>
        {trailingIcon && (
          <Icon name={trailingIcon} size={14} />
        )}
      </button>

      <span className={styles.line} aria-hidden="true" />
    </div>
  );
}
