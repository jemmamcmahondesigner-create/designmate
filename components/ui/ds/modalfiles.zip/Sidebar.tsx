'use client';

import { Icon } from './index';
import { NotificationBadge } from './NotificationBadge';
import { ShowAccordion } from './ShowAccordion';
import { Avatar } from './Avatar';
import styles from './Sidebar.module.css';

export type SidebarState = 'default' | 'minimised' | 'expanded';

export interface SidebarProject {
  id: string;
  name: string;
  clientName: string;
  /** Whether this project has unread activity */
  hasActivity?: boolean;
  /** Whether this project is currently active/selected */
  active?: boolean;
}

export interface SidebarProps {
  state?: SidebarState;
  /** Currently active nav section */
  activeNav?: 'projects' | 'reviews';
  /** Projects to list under the Projects section */
  projects?: SidebarProject[];
  /** Whether Projects accordion is open */
  projectsOpen?: boolean;
  /** Callback when Projects header is toggled */
  onProjectsToggle?: () => void;
  /** Callback when "View all" / "Show more" is clicked */
  onShowAll?: () => void;
  /** Callback when a project is clicked */
  onProjectClick?: (id: string) => void;
  /** Callback when All Reviews is clicked */
  onReviewsClick?: () => void;
  /** Current user */
  user?: { name: string; avatarSrc?: string };
  /** Max projects shown before ShowAccordion triggers */
  maxVisible?: number;
  className?: string;
}

const PROJECT_THRESHOLD = 5;

export function Sidebar({
  state = 'default',
  activeNav = 'projects',
  projects = [],
  projectsOpen = true,
  onProjectsToggle,
  onShowAll,
  onProjectClick,
  onReviewsClick,
  user,
  maxVisible = PROJECT_THRESHOLD,
  className,
}: SidebarProps) {
  const isMinimised = state === 'minimised';
  const isExpanded = state === 'expanded';

  const rootClass = [
    styles.root,
    isMinimised ? styles.minimised : '',
    className ?? '',
  ]
    .filter(Boolean)
    .join(' ');

  const visibleProjects = projects.slice(0, maxVisible);
  const hasMore = projects.length > maxVisible;

  return (
    <nav className={rootClass} aria-label="Main navigation">
      {/* ── Logo / Brand ── */}
      <div className={styles.brand}>
        <div className={styles.brandMark}>
          <Icon name="nav-mark" size={24} />
        </div>
        {!isMinimised && (
          <span className={styles.brandName}>DesignMate</span>
        )}
      </div>

      {/* ── Minimised: icon-only nav ── */}
      {isMinimised && (
        <>
          <div className={styles.iconNav}>
            <button
              type="button"
              className={[
                styles.iconNavBtn,
                activeNav === 'projects' ? styles.iconNavBtnActive : '',
              ].filter(Boolean).join(' ')}
              onClick={onProjectsToggle}
              aria-label="Projects"
            >
              <Icon name="nav-archive" size={20} />
            </button>
            <button
              type="button"
              className={[
                styles.iconNavBtn,
                activeNav === 'reviews' ? styles.iconNavBtnActive : '',
              ].filter(Boolean).join(' ')}
              onClick={onReviewsClick}
              aria-label="All Reviews"
            >
              <Icon name="nav-reviews" size={20} />
            </button>
          </div>
          <div className={styles.footerDivider} />
          <div className={styles.footerMin}>
            <Avatar src={user?.avatarSrc} name={user?.name} size="md" />
          </div>
        </>
      )}

      {/* ── Default / Expanded: full nav ── */}
      {!isMinimised && (
        <>
          <div className={styles.workspace}>
            {/* Workspace heading */}
            <div className={styles.workspaceHeading}>
              <span className={styles.sectionLabel}>WORKSPACE</span>
            </div>

            {/* Projects accordion header */}
            <div className={styles.navItems}>
              <button
                type="button"
                className={[
                  styles.navItem,
                  activeNav === 'projects' && projectsOpen ? styles.navItemActive : '',
                ].filter(Boolean).join(' ')}
                onClick={onProjectsToggle}
                aria-expanded={projectsOpen}
              >
                <Icon name="nav-archive" size={20} className={styles.navIcon} />
                <span className={styles.navLabel}>Projects</span>
                <Icon
                  name={projectsOpen ? 'chevron-up' : 'chevron-down'}
                  size={20}
                  className={styles.navChevron}
                />
              </button>

              {/* Project list */}
              {projectsOpen && (
                <div className={styles.subItems}>
                  {visibleProjects.map((project) => (
                    <button
                      key={project.id}
                      type="button"
                      className={[
                        styles.subItem,
                        project.active ? styles.subItemActive : '',
                      ].filter(Boolean).join(' ')}
                      onClick={() => onProjectClick?.(project.id)}
                    >
                      <span className={styles.subItemLabels}>
                        <span className={[
                          styles.subItemName,
                          project.active ? styles.subItemNameActive : '',
                        ].filter(Boolean).join(' ')}>
                          {project.name}
                        </span>
                        <span className={[
                          styles.subItemClient,
                          project.active ? styles.subItemClientActive : '',
                        ].filter(Boolean).join(' ')}>
                          {project.clientName}
                        </span>
                      </span>
                      {project.hasActivity && (
                        <NotificationBadge variant="dot" sentiment="success" />
                      )}
                    </button>
                  ))}

                  {/* Show accordion — triggers when > maxVisible projects */}
                  {hasMore && (
                    <ShowAccordion state="view-all" onClick={onShowAll} />
                  )}
                </div>
              )}

              {/* All Reviews */}
              <button
                type="button"
                className={[
                  styles.navItem,
                  activeNav === 'reviews' ? styles.navItemActive : '',
                ].filter(Boolean).join(' ')}
                onClick={onReviewsClick}
              >
                <Icon name="nav-reviews" size={20} className={styles.navIcon} />
                <span className={styles.navLabel}>All Reviews</span>
                <Icon name="chevron-right" size={20} className={styles.navChevron} />
              </button>
            </div>
          </div>

          <div className={styles.footerDivider} />

          {/* User footer */}
          <div className={styles.footer}>
            <Avatar src={user?.avatarSrc} name={user?.name} size="md" />
            <span className={styles.userName}>{user?.name}</span>
          </div>
        </>
      )}
    </nav>
  );
}
